package com.example.apigateway.Config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()                
                .route("customer-service", r -> r.path("/api/accounts/**")
                        .uri("lb://customer-service"))
                .route("customer-service", r -> r.path("/api/activities/**")
                        .uri("lb://customer-service"))
                .route("customer-service", r -> r.path("/api/cases/**")
                        .uri("lb://customer-service"))
                .route("customer-service", r -> r.path("/api/contacts/**")
                        .uri("lb://customer-service"))       
                .route("customer-service", r -> r.path("/api/customers/**")
                        .uri("lb://customer-service"))
                .route("customer-service", r -> r.path("/api/KnowledgeArticle/**")
                        .uri("lb://customer-service"))
                .route("employee-service", r -> r.path("/api/attendances/**")
                        .uri("lb://employee-service"))
                .route("employee-service", r -> r.path("/api/employees/**")
                        .uri("lb://employee-service"))
                .route("employee-service", r -> r.path("/api/payrolls/**")
                        .uri("lb://employee-service"))
                .route("employee-service", r -> r.path("/api/performancereviews/**")
                        .uri("lb://employee-service"))
                .route("employee-service", r -> r.path("/api/teams/**")
                        .uri("lb://employee-service"))
                .route("employee-service", r -> r.path("/api/trainings/**")
                        .uri("lb://employee-service"))
                .route("lead-service", r -> r.path("/api/lead-activities/**")
                        .uri("lb://lead-service"))
                .route("lead-service", r -> r.path("/api/leads/**")
                        .uri("lb://lead-service"))
                .route("lead-service", r -> r.path("/api/lead-scores/**")
                        .uri("lb://lead-service"))
                .route("lead-service", r -> r.path("/api/lead-scores/**")
                        .uri("lb://lead-service"))
                .route("lead-service", r -> r.path("/api/lead-sources/**")
                        .uri("lb://lead-service"))
                .route("lead-service", r -> r.path("/api/lead-statuses/**")
                        .uri("lb://lead-service"))         
                .route("marketing-service", r -> r.path("/api/campaign-activities/**")
                        .uri("lb://marketing-service")) 
                .route("marketing-service", r -> r.path("/api/campaigns/**")
                        .uri("lb://marketing-service"))         
                .route("marketing-service", r -> r.path("/api/events/**")
                        .uri("lb://marketing-service"))
                .route("marketing-service", r -> r.path("/api/marketing-lists/**")
                        .uri("lb://marketing-service"))
                .route("marketing-service", r -> r.path("/api/surveys/**")
                        .uri("lb://marketing-service"))
                .route("sales-service", r -> r.path("/invoices/**")
                        .uri("lb://sales-service"))
                .route("sales-service", r -> r.path("/opportunities/**")
                        .uri("lb://sales-service"))
                .route("sales-service", r -> r.path("/orders/**")
                        .uri("lb://sales-service"))
                .route("sales-service", r -> r.path("/products/**")
                        .uri("lb://sales-service"))
                .route("sales-service", r -> r.path("/quotes/**")
                        .uri("lb://sales-service"))
                .route("sales-service", r -> r.path("/salesTargets/**")
                        .uri("lb://sales-service"))
                .route("support_and_analytics_service", r -> r.path("/api/analyticsReports/**")
                        .uri("lb://support_and_analytics_service"))
                .route("support_and_analytics_service", r -> r.path("/api/feedbacks/**")
                        .uri("lb://support_and_analytics_service"))
                .route("support_and_analytics_service", r -> r.path("/api/performanceMetrics/**")
                        .uri("lb://support_and_analytics_service"))
                .route("support_and_analytics_service", r -> r.path("/api/supportTickets/**")
                        .uri("lb://support_and_analytics_service"))
                .route("support_and_analytics_service", r -> r.path("/api/surveyResponses/**")
                        .uri("lb://support_and_analytics_service"))
                        .build();
    }
}

    

