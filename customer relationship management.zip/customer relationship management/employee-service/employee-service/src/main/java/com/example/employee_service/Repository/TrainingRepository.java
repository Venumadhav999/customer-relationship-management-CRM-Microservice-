package com.example.employee_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.employee_service.Entity.Training;

@Repository
public interface TrainingRepository extends JpaRepository<Training, Long>{
    
}
