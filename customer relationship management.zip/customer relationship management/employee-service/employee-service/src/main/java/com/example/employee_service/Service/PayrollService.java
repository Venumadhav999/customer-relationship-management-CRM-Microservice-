package com.example.employee_service.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee_service.Entity.Payroll;
import com.example.employee_service.Repository.PayrollRepository;

@Service
public class PayrollService {
    @Autowired
    private PayrollRepository payrollRepository;

    public List<Payroll> getAllPayrolls() {
        return payrollRepository.findAll();
    }

    public Optional<Payroll> getPayrollById(Long id) {
        return payrollRepository.findById(id);
    }

    public Payroll createPayroll(Payroll payroll) {
        return payrollRepository.save(payroll);
    }

    public Payroll updatePayroll(Long id, Payroll payrollDetails) {
        Optional<Payroll> payrollOptional = payrollRepository.findById(id);

        if (payrollOptional.isPresent()) {
            Payroll payroll = payrollOptional.get();
            payroll.setSalary(payrollDetails.getSalary());
            payroll.setPaymentDate(payrollDetails.getPaymentDate());
            payroll.setEmployee(payrollDetails.getEmployee());
            return payrollRepository.save(payroll);
        } else {
            return null;
        }
    }

    public void deletePayroll(Long id) {
        payrollRepository.deleteById(id);
    }
}
