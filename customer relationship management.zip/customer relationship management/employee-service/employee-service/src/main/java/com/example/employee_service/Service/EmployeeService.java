package com.example.employee_service.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee_service.Entity.Employee;
import com.example.employee_service.Repository.EmployeeRepository;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(Long id) {
        return employeeRepository.findById(id);
    }

    public Employee createEmployee(Employee employee) {
        // Set employee reference on related entities
        if (employee.getPerformanceReviews() != null) {
            employee.getPerformanceReviews().forEach(review -> review.setEmployee(employee));
        }
        if (employee.getAttendances() != null) {
            employee.getAttendances().forEach(attendance -> attendance.setEmployee(employee));
        }
        if (employee.getPayrolls() != null) {
            employee.getPayrolls().forEach(payroll -> payroll.setEmployee(employee));
        }
        if (employee.getTrainings() != null) {
            employee.getTrainings().forEach(training -> training.setEmployee(employee));
        }
        return employeeRepository.save(employee);
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    public Employee updateEmployee(Long id, Employee employeeDetails) {
        Optional<Employee> employeeOptional = employeeRepository.findById(id);

        if (employeeOptional.isPresent()) {
            Employee employee = employeeOptional.get();
            employee.setFirstName(employeeDetails.getFirstName());
            employee.setLastName(employeeDetails.getLastName());
            employee.setEmail(employeeDetails.getEmail());
            employee.setPerformanceReviews(employeeDetails.getPerformanceReviews());
            employee.setAttendances(employeeDetails.getAttendances());
            employee.setPayrolls(employeeDetails.getPayrolls());
            employee.setTrainings(employeeDetails.getTrainings());
            employee.setTeam(employeeDetails.getTeam());

            // Set employee reference on related entities
            if (employee.getPerformanceReviews() != null) {
                employee.getPerformanceReviews().forEach(review -> review.setEmployee(employee));
            }
            if (employee.getAttendances() != null) {
                employee.getAttendances().forEach(attendance -> attendance.setEmployee(employee));
            }
            if (employee.getPayrolls() != null) {
                employee.getPayrolls().forEach(payroll -> payroll.setEmployee(employee));
            }
            if (employee.getTrainings() != null) {
                employee.getTrainings().forEach(training -> training.setEmployee(employee));
            }
            return employeeRepository.save(employee);
        } else {
            return null;
        }
    }
}
