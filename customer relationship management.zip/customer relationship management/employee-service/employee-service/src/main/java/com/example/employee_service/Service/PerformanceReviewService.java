package com.example.employee_service.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.employee_service.Entity.PerformanceReview;
import com.example.employee_service.Repository.PerformanceReviewRepository;

@Service
public class PerformanceReviewService {
    @Autowired
    private PerformanceReviewRepository performanceReviewRepository;

    public List<PerformanceReview> getAllPerformanceReviews() {
        return performanceReviewRepository.findAll();
    }

    public Optional<PerformanceReview> getPerformanceReviewById(Long id) {
        return performanceReviewRepository.findById(id);
    }

    public PerformanceReview createPerformanceReview(PerformanceReview performanceReview) {
        return performanceReviewRepository.save(performanceReview);
    }

    public PerformanceReview updatePerformanceReview(Long id, PerformanceReview performanceReviewDetails) {
        Optional<PerformanceReview> performanceReviewOptional = performanceReviewRepository.findById(id);

        if (performanceReviewOptional.isPresent()) {
            PerformanceReview performanceReview = performanceReviewOptional.get();
            performanceReview.setReviewDate(performanceReviewDetails.getReviewDate());
            performanceReview.setComments(performanceReviewDetails.getComments());
            performanceReview.setEmployee(performanceReviewDetails.getEmployee());
            return performanceReviewRepository.save(performanceReview);
        } else {
            return null;
        }
    }

    public void deletePerformanceReview(Long id) {
        performanceReviewRepository.deleteById(id);
    }
}
