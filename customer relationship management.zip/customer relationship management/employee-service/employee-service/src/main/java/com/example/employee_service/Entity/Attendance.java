package com.example.employee_service.Entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
public class Attendance {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDate date;
    private boolean present;

    @ManyToOne
     @JsonBackReference
    private Employee employee;

    public Attendance() {}

    public Attendance(Long id, LocalDate date, boolean present, Employee employee) {
        this.id = id;
        this.date = date;
        this.present = present;
        this.employee = employee;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    public boolean isPresent() { return present; }
    public void setPresent(boolean present) { this.present = present; }
    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }

    @Override
    public String toString() {
        return "Attendance [id=" + id + ", date=" + date + ", present=" + present + ", employee=" + employee + "]";
    }

    
}
