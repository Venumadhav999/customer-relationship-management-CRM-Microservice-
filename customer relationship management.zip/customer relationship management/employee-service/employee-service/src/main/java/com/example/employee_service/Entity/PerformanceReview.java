package com.example.employee_service.Entity;

import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
public class PerformanceReview {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private LocalDate reviewDate;
    private String comments;

    @ManyToOne
    @JsonBackReference
    private Employee employee;

    public PerformanceReview() {}

    public PerformanceReview(Long id, LocalDate reviewDate, String comments, Employee employee) {
        this.id = id;
        this.reviewDate = reviewDate;
        this.comments = comments;
        this.employee = employee;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public LocalDate getReviewDate() { return reviewDate; }
    public void setReviewDate(LocalDate reviewDate) { this.reviewDate = reviewDate; }
    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }
    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }

    @Override
    public String toString() {
        return "PerformanceReview [id=" + id + ", reviewDate=" + reviewDate + ", comments=" + comments + ", employee="
                + employee + "]";
    }

    
}
