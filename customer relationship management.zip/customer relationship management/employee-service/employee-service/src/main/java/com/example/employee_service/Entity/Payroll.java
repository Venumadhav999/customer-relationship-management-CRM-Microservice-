package com.example.employee_service.Entity;

import java.math.BigDecimal;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
public class Payroll {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private BigDecimal salary;
    private LocalDate paymentDate;

    @ManyToOne
    @JsonBackReference
    private Employee employee;

    public Payroll() {}

    public Payroll(Long id, BigDecimal salary, LocalDate paymentDate, Employee employee) {
        this.id = id;
        this.salary = salary;
        this.paymentDate = paymentDate;
        this.employee = employee;
    }

    // Getters and setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public BigDecimal getSalary() { return salary; }
    public void setSalary(BigDecimal salary) { this.salary = salary; }
    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }
    public Employee getEmployee() { return employee; }
    public void setEmployee(Employee employee) { this.employee = employee; }

    @Override
    public String toString() {
        return "Payroll [id=" + id + ", salary=" + salary + ", paymentDate=" + paymentDate + ", employee=" + employee
                + "]";
    }

    
}
