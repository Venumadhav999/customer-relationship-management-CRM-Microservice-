package com.example.employee_service.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.employee_service.Entity.PerformanceReview;
import com.example.employee_service.Service.PerformanceReviewService;

@RestController
@RequestMapping("/api/performanceReviews")
public class PerformanceReviewController {

    @Autowired
    private PerformanceReviewService performanceReviewService;

    @GetMapping
    public List<PerformanceReview> getAllPerformanceReviews() {
        return performanceReviewService.getAllPerformanceReviews();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PerformanceReview> getPerformanceReviewById(@PathVariable Long id) {
        Optional<PerformanceReview> performanceReview = performanceReviewService.getPerformanceReviewById(id);
        if (performanceReview.isPresent()) {
            return new ResponseEntity<>(performanceReview.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<PerformanceReview> createPerformanceReview(@RequestBody PerformanceReview performanceReview) {
        PerformanceReview createdPerformanceReview = performanceReviewService.createPerformanceReview(performanceReview);
        return new ResponseEntity<>(createdPerformanceReview, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PerformanceReview> updatePerformanceReview(@PathVariable Long id, @RequestBody PerformanceReview performanceReviewDetails) {
        PerformanceReview updatedPerformanceReview = performanceReviewService.updatePerformanceReview(id, performanceReviewDetails);
        if (updatedPerformanceReview != null) {
            return new ResponseEntity<>(updatedPerformanceReview, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePerformanceReview(@PathVariable Long id) {
        performanceReviewService.deletePerformanceReview(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
