package com.example.marketing_service.Service;

import com.example.marketing_service.Entity.CampaignActivity;
import com.example.marketing_service.Repository.CampaignActivityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CampaignActivityService {
    @Autowired
    private CampaignActivityRepository campaignActivityRepository;

    public List<CampaignActivity> getAllCampaignActivities() {
        return campaignActivityRepository.findAll();
    }

    public Optional<CampaignActivity> getCampaignActivityById(Long id) {
        return campaignActivityRepository.findById(id);
    }

    public CampaignActivity saveCampaignActivity(CampaignActivity campaignActivity) {
        return campaignActivityRepository.save(campaignActivity);
    }

    public void deleteCampaignActivity(Long id) {
        campaignActivityRepository.deleteById(id);
    }
}
