package com.example.marketing_service.Service;

import com.example.marketing_service.Entity.MarketingList;
import com.example.marketing_service.Repository.MarketingListRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MarketingListService {
    @Autowired
    private MarketingListRepository marketingListRepository;

    public List<MarketingList> getAllMarketingLists() {
        return marketingListRepository.findAll();
    }

    public Optional<MarketingList> getMarketingListById(Long id) {
        return marketingListRepository.findById(id);
    }

    public MarketingList saveMarketingList(MarketingList marketingList) {
        return marketingListRepository.save(marketingList);
    }

    public void deleteMarketingList(Long id) {
        marketingListRepository.deleteById(id);
    }
}
