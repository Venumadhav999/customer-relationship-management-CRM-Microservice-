package com.example.marketing_service.Controller;

import com.example.marketing_service.Entity.Campaign;
import com.example.marketing_service.Service.CampaignService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/campaigns")
public class CampaignController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CampaignController.class);
    private final CampaignService campaignService;

    public CampaignController(CampaignService campaignService) {
        this.campaignService = campaignService;
    }

    @PostMapping
    public ResponseEntity<Campaign> createCampaign(@RequestBody Campaign campaign) {
        LOGGER.info("Creating campaign: {}", campaign);
        Campaign createdCampaign = campaignService.saveCampaign(campaign);
        return new ResponseEntity<>(createdCampaign, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Campaign>> getAllCampaigns() {
        LOGGER.info("Fetching all campaigns");
        List<Campaign> campaigns = campaignService.getAllCampaigns();
        return new ResponseEntity<>(campaigns, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Campaign> getCampaignById(@PathVariable Long id) {
        LOGGER.info("Fetching campaign by ID: {}", id);
        Optional<Campaign> campaign = campaignService.getCampaignById(id);
        return campaign.map(c -> new ResponseEntity<>(c, HttpStatus.OK))
                       .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Campaign> updateCampaign(@PathVariable Long id, @RequestBody Campaign campaignDetails) {
        LOGGER.info("Updating campaign with ID {}: {}", id, campaignDetails);
        Optional<Campaign> campaign = campaignService.getCampaignById(id);
        if (campaign.isPresent()) {
            Campaign updatedCampaign = campaign.get();
            updatedCampaign.setName(campaignDetails.getName());
            updatedCampaign.setDescription(campaignDetails.getDescription());
            updatedCampaign.setStartDate(campaignDetails.getStartDate());
            updatedCampaign.setEndDate(campaignDetails.getEndDate());
            updatedCampaign.setBudget(campaignDetails.getBudget());
            updatedCampaign.setStatus(campaignDetails.getStatus());
            updatedCampaign.setCampaignActivities(campaignDetails.getCampaignActivities());
            updatedCampaign.setEvents(campaignDetails.getEvents());
            updatedCampaign.setMarketingLists(campaignDetails.getMarketingLists());
            updatedCampaign.setSurveys(campaignDetails.getSurveys());
            return new ResponseEntity<>(campaignService.saveCampaign(updatedCampaign), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCampaign(@PathVariable Long id) {
        LOGGER.info("Deleting campaign with ID: {}", id);
        if (campaignService.getCampaignById(id).isPresent()) {
            campaignService.deleteCampaign(id);
            return ResponseEntity.ok("Campaign deleted successfully");
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
