package com.example.marketing_service.Controller;

import com.example.marketing_service.Entity.Survey;
import com.example.marketing_service.Service.SurveyService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/surveys")
public class SurveyController {
    private static final Logger LOGGER = LoggerFactory.getLogger(SurveyController.class);
    private final SurveyService surveyService;

    public SurveyController(SurveyService surveyService) {
        this.surveyService = surveyService;
    }

    @PostMapping
    public ResponseEntity<Survey> createSurvey(@RequestBody Survey survey) {
        LOGGER.info("Creating survey: {}", survey);
        Survey createdSurvey = surveyService.saveSurvey(survey);
        return new ResponseEntity<>(createdSurvey, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Survey>> getAllSurveys() {
        LOGGER.info("Fetching all surveys");
        List<Survey> surveys = surveyService.getAllSurveys();
        return new ResponseEntity<>(surveys, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Survey> getSurveyById(@PathVariable Long id) {
        LOGGER.info("Fetching survey by ID: {}", id);
        Optional<Survey> survey = surveyService.getSurveyById(id);
        return survey.map(s -> new ResponseEntity<>(s, HttpStatus.OK))
                     .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Survey> updateSurvey(@PathVariable Long id, @RequestBody Survey surveyDetails) {
        LOGGER.info("Updating survey with ID {}: {}", id, surveyDetails);
        Optional<Survey> survey = surveyService.getSurveyById(id);
        if (survey.isPresent()) {
            Survey updatedSurvey = survey.get();
            updatedSurvey.setName(surveyDetails.getName());
            updatedSurvey.setDescription(surveyDetails.getDescription());
            updatedSurvey.setCreationDate(surveyDetails.getCreationDate());
            updatedSurvey.setQuestions(surveyDetails.getQuestions());
            updatedSurvey.setResponses(surveyDetails.getResponses());
            updatedSurvey.setCampaign(surveyDetails.getCampaign());
            return new ResponseEntity<>(surveyService.saveSurvey(updatedSurvey), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteSurvey(@PathVariable Long id) {
        LOGGER.info("Deleting survey with ID: {}", id);
        if (surveyService.getSurveyById(id).isPresent()) {
            surveyService.deleteSurvey(id);
            return ResponseEntity.ok("Survey deleted successfully");
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
