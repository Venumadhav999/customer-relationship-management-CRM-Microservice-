package com.example.marketing_service.Controller;

import com.example.marketing_service.Entity.MarketingList;
import com.example.marketing_service.Service.MarketingListService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/marketing-lists")
public class MarketingListController {
    private static final Logger LOGGER = LoggerFactory.getLogger(MarketingListController.class);
    private final MarketingListService marketingListService;

    public MarketingListController(MarketingListService marketingListService) {
        this.marketingListService = marketingListService;
    }

    @PostMapping
    public ResponseEntity<MarketingList> createMarketingList(@RequestBody MarketingList marketingList) {
        LOGGER.info("Creating marketing list: {}", marketingList);
        MarketingList createdMarketingList = marketingListService.saveMarketingList(marketingList);
        return new ResponseEntity<>(createdMarketingList, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<MarketingList>> getAllMarketingLists() {
        LOGGER.info("Fetching all marketing lists");
        List<MarketingList> marketingLists = marketingListService.getAllMarketingLists();
        return new ResponseEntity<>(marketingLists, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MarketingList> getMarketingListById(@PathVariable Long id) {
        LOGGER.info("Fetching marketing list by ID: {}", id);
        Optional<MarketingList> marketingList = marketingListService.getMarketingListById(id);
        return marketingList.map(ml -> new ResponseEntity<>(ml, HttpStatus.OK))
                            .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/{id}")
    public ResponseEntity<MarketingList> updateMarketingList(@PathVariable Long id, @RequestBody MarketingList marketingListDetails) {
        LOGGER.info("Updating marketing list with ID {}: {}", id, marketingListDetails);
        Optional<MarketingList> marketingList = marketingListService.getMarketingListById(id);
        if (marketingList.isPresent()) {
            MarketingList updatedMarketingList = marketingList.get();
            updatedMarketingList.setName(marketingListDetails.getName());
            updatedMarketingList.setDescription(marketingListDetails.getDescription());
            updatedMarketingList.setCreationDate(marketingListDetails.getCreationDate());
            updatedMarketingList.setListType(marketingListDetails.getListType());
            updatedMarketingList.setCampaign(marketingListDetails.getCampaign());
            return new ResponseEntity<>(marketingListService.saveMarketingList(updatedMarketingList), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteMarketingList(@PathVariable Long id) {
        LOGGER.info("Deleting marketing list with ID: {}", id);
        if (marketingListService.getMarketingListById(id).isPresent()) {
            marketingListService.deleteMarketingList(id);
            return ResponseEntity.ok("Marketing list deleted successfully");
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
