package com.example.marketing_service.Repository;

import com.example.marketing_service.Entity.MarketingList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MarketingListRepository extends JpaRepository<MarketingList, Long> {
}
