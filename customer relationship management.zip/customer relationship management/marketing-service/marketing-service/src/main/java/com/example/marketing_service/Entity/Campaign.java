package com.example.marketing_service.Entity;


import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;



@Entity
public class Campaign {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long campaignId;
    
    private String name;
    private String description;
    private Date startDate;
    private Date endDate;
    private Double budget;
    private String status;

    @OneToMany(mappedBy = "campaign", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("campaign")
    @JsonManagedReference
    private List<CampaignActivity> campaignActivities;

    @OneToMany(mappedBy = "campaign", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("campaign")
    @JsonManagedReference
    private List<Event> events;

    @OneToMany(mappedBy = "campaign", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("campaign")
    @JsonManagedReference
    private List<MarketingList> marketingLists ;

    @OneToMany(mappedBy = "campaign", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("campaign")
    @JsonManagedReference
    private List<Survey> surveys ;

    public Campaign() {
    }

    public Campaign(Long campaignId, String name, String description, Date startDate, Date endDate, Double budget,
            String status, List<CampaignActivity> campaignActivities, List<Event> events,
            List<MarketingList> marketingLists, List<Survey> surveys) {
        this.campaignId = campaignId;
        this.name = name;
        this.description = description;
        this.startDate = startDate;
        this.endDate = endDate;
        this.budget = budget;
        this.status = status;
        this.campaignActivities = campaignActivities;
        this.events = events;
        this.marketingLists = marketingLists;
        this.surveys = surveys;
    }

    public Long getCampaignId() {
        return campaignId;
    }

    public void setCampaignId(Long campaignId) {
        this.campaignId = campaignId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public Double getBudget() {
        return budget;
    }

    public void setBudget(Double budget) {
        this.budget = budget;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<CampaignActivity> getCampaignActivities() {
        return campaignActivities;
    }

    public void setCampaignActivities(List<CampaignActivity> campaignActivities) {
        this.campaignActivities = campaignActivities;
    }

    public List<Event> getEvents() {
        return events;
    }

    public void setEvents(List<Event> events) {
        this.events = events;
    }

    public List<MarketingList> getMarketingLists() {
        return marketingLists;
    }

    public void setMarketingLists(List<MarketingList> marketingLists) {
        this.marketingLists = marketingLists;
    }

    public List<Survey> getSurveys() {
        return surveys;
    }

    public void setSurveys(List<Survey> surveys) {
        this.surveys = surveys;
    }

    @Override
    public String toString() {
        return "Campaign [campaignId=" + campaignId + ", name=" + name + ", description=" + description + ", startDate="
                + startDate + ", endDate=" + endDate + ", budget=" + budget + ", status=" + status
                + ", campaignActivities=" + campaignActivities + ", events=" + events + ", marketingLists="
                + marketingLists + ", surveys=" + surveys + "]";
    }


}