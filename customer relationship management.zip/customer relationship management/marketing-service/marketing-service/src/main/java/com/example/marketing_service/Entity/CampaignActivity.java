package com.example.marketing_service.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class CampaignActivity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long activityId;

    @ManyToOne
    @JsonBackReference
    private Campaign campaign;

    private String type;
    private Date date;
    private String status;
    private Double responseRate;

    public CampaignActivity() {}

    public CampaignActivity(Long activityId, Campaign campaign, String type, Date date, String status,
            Double responseRate) {
        this.activityId = activityId;
        this.campaign = campaign;
        this.type = type;
        this.date = date;
        this.status = status;
        this.responseRate = responseRate;
    }

    public Long getActivityId() {
        return activityId;
    }

    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Double getResponseRate() {
        return responseRate;
    }

    public void setResponseRate(Double responseRate) {
        this.responseRate = responseRate;
    }

    @Override
    public String toString() {
        return "CampaignActivity [activityId=" + activityId + ", campaign=" + campaign + ", type=" + type + ", date="
                + date + ", status=" + status + ", responseRate=" + responseRate + "]";
    }
    

}