package com.example.marketing_service.Controller;

import com.example.marketing_service.Entity.Event;
import com.example.marketing_service.Service.EventService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/events")
public class EventController {
    private static final Logger LOGGER = LoggerFactory.getLogger(EventController.class);
    private final EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @PostMapping
    public ResponseEntity<Event> createEvent(@RequestBody Event event) {
        LOGGER.info("Creating event: {}", event);
        Event createdEvent = eventService.saveEvent(event);
        return new ResponseEntity<>(createdEvent, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Event>> getAllEvents() {
        LOGGER.info("Fetching all events");
        List<Event> events = eventService.getAllEvents();
        return new ResponseEntity<>(events, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Event> getEventById(@PathVariable Long id) {
        LOGGER.info("Fetching event by ID: {}", id);
        Optional<Event> event = eventService.getEventById(id);
        return event.map(e -> new ResponseEntity<>(e, HttpStatus.OK))
                    .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Event> updateEvent(@PathVariable Long id, @RequestBody Event eventDetails) {
        LOGGER.info("Updating event with ID {}: {}", id, eventDetails);
        Optional<Event> event = eventService.getEventById(id);
        if (event.isPresent()) {
            Event updatedEvent = event.get();
            updatedEvent.setName(eventDetails.getName());
            updatedEvent.setDescription(eventDetails.getDescription());
            updatedEvent.setDate(eventDetails.getDate());
            updatedEvent.setLocation(eventDetails.getLocation());
            updatedEvent.setOrganizer(eventDetails.getOrganizer());
            updatedEvent.setAttendeesCount(eventDetails.getAttendeesCount());
            updatedEvent.setCampaign(eventDetails.getCampaign());
            return new ResponseEntity<>(eventService.saveEvent(updatedEvent), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteEvent(@PathVariable Long id) {
        LOGGER.info("Deleting event with ID: {}", id);
        if (eventService.getEventById(id).isPresent()) {
            eventService.deleteEvent(id);
            return ResponseEntity.ok("Event deleted successfully");
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
