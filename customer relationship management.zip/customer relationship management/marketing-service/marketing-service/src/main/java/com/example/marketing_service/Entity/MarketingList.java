package com.example.marketing_service.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonBackReference;



@Entity
public class MarketingList {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long listId;

    private String name;
    private String description;
    private Date creationDate;
    private String listType;
    private String content;

    @ManyToOne
    @JsonBackReference
    private Campaign campaign;

    public MarketingList() {}

    public MarketingList(Long listId, String name, String description, Date creationDate, String listType,
            String content, Campaign campaign) {
        this.listId = listId;
        this.name = name;
        this.description = description;
        this.creationDate = creationDate;
        this.listType = listType;
        this.content = content;
        this.campaign = campaign;
    }

    public Long getListId() {
        return listId;
    }

    public void setListId(Long listId) {
        this.listId = listId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public String getListType() {
        return listType;
    }

    public void setListType(String listType) {
        this.listType = listType;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    @Override
    public String toString() {
        return "MarketingList [listId=" + listId + ", name=" + name + ", description=" + description + ", creationDate="
                + creationDate + ", listType=" + listType + ", content=" + content + ", campaign=" + campaign + "]";
    }

}