package com.example.marketing_service.Entity;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Survey {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long surveyId;

    private String name;
    private String description;
    private Date creationDate;

    @ElementCollection
    private List<String> questions;

    @ElementCollection
    private List<String> responses;

    @ManyToOne
    @JsonBackReference
    private Campaign campaign;

    public Survey() {}

    public Survey(Long surveyId, String name, String description, Date creationDate, List<String> questions,
            List<String> responses, Campaign campaign) {
        this.surveyId = surveyId;
        this.name = name;
        this.description = description;
        this.creationDate = creationDate;
        this.questions = questions;
        this.responses = responses;
        this.campaign = campaign;
    }

    public Long getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(Long surveyId) {
        this.surveyId = surveyId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    public List<String> getQuestions() {
        return questions;
    }

    public void setQuestions(List<String> questions) {
        this.questions = questions;
    }

    public List<String> getResponses() {
        return responses;
    }

    public void setResponses(List<String> responses) {
        this.responses = responses;
    }

    public Campaign getCampaign() {
        return campaign;
    }

    public void setCampaign(Campaign campaign) {
        this.campaign = campaign;
    }

    @Override
    public String toString() {
        return "Survey [surveyId=" + surveyId + ", name=" + name + ", description=" + description + ", creationDate="
                + creationDate + ", questions=" + questions + ", responses=" + responses + ", campaign=" + campaign
                + "]";
    }

}

