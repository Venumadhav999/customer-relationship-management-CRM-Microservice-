package com.example.marketing_service.Controller;

import com.example.marketing_service.Entity.CampaignActivity;
import com.example.marketing_service.Service.CampaignActivityService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/campaign-activities")
public class CampaignActivityController {
    private static final Logger LOGGER = LoggerFactory.getLogger(CampaignActivityController.class);
    private final CampaignActivityService campaignActivityService;

    public CampaignActivityController(CampaignActivityService campaignActivityService) {
        this.campaignActivityService = campaignActivityService;
    }

    @PostMapping
    public ResponseEntity<CampaignActivity> createCampaignActivity(@RequestBody CampaignActivity campaignActivity) {
        LOGGER.info("Creating campaign activity: {}", campaignActivity);
        CampaignActivity createdCampaignActivity = campaignActivityService.saveCampaignActivity(campaignActivity);
        return new ResponseEntity<>(createdCampaignActivity, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<CampaignActivity>> getAllCampaignActivities() {
        LOGGER.info("Fetching all campaign activities");
        List<CampaignActivity> campaignActivities = campaignActivityService.getAllCampaignActivities();
        return new ResponseEntity<>(campaignActivities, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CampaignActivity> getCampaignActivityById(@PathVariable Long id) {
        LOGGER.info("Fetching campaign activity by ID: {}", id);
        Optional<CampaignActivity> campaignActivity = campaignActivityService.getCampaignActivityById(id);
        return campaignActivity.map(ca -> new ResponseEntity<>(ca, HttpStatus.OK))
                               .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CampaignActivity> updateCampaignActivity(@PathVariable Long id, @RequestBody CampaignActivity campaignActivityDetails) {
        LOGGER.info("Updating campaign activity with ID {}: {}", id, campaignActivityDetails);
        Optional<CampaignActivity> campaignActivity = campaignActivityService.getCampaignActivityById(id);
        if (campaignActivity.isPresent()) {
            CampaignActivity updatedCampaignActivity = campaignActivity.get();
            updatedCampaignActivity.setCampaign(campaignActivityDetails.getCampaign());
            updatedCampaignActivity.setType(campaignActivityDetails.getType());
            updatedCampaignActivity.setDate(campaignActivityDetails.getDate());
            updatedCampaignActivity.setStatus(campaignActivityDetails.getStatus());
            updatedCampaignActivity.setResponseRate(campaignActivityDetails.getResponseRate());
            return new ResponseEntity<>(campaignActivityService.saveCampaignActivity(updatedCampaignActivity), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCampaignActivity(@PathVariable Long id) {
        LOGGER.info("Deleting campaign activity with ID: {}", id);
        if (campaignActivityService.getCampaignActivityById(id).isPresent()) {
            campaignActivityService.deleteCampaignActivity(id);
            return ResponseEntity.ok("Campaign activity deleted successfully");
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}
