package com.example.sales_service.Service;

import com.example.sales_service.Entity.Product;
import com.example.sales_service.Repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {
    @Autowired
    private ProductRepository productRepository;

    public List<Product> findAll() {
        return productRepository.findAll();
    }

    public Product findById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    public Product save(Product product) {
        return productRepository.save(product);
    }

    public void deleteById(Long id) {
        productRepository.deleteById(id);
    }

    public Product updateProduct(Long id, Product productDeatils){
        Optional<Product> producOptional=productRepository.findById(id);

        if(producOptional.isPresent()){
            Product product = producOptional.get();
            product.setName(productDeatils.getName());
            product.setDescription(productDeatils.getDescription());
            product.setPrice(productDeatils.getPrice());
            product.setOpportunity(productDeatils.getOpportunity());

            return productRepository.save(product);
        }
        else{
            return null;
        }
    }
}
