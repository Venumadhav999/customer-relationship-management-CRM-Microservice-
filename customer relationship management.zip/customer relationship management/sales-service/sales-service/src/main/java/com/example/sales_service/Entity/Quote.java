package com.example.sales_service.Entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;


@Entity
public class Quote {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JsonBackReference
    private Opportunity opportunity;

    private String description;
    private double amount;
    private LocalDateTime quoteDate;

    public Quote() {}

    public Quote(Long id, Opportunity opportunity, String description, double amount, LocalDateTime quoteDate) {
        this.id = id;
        this.opportunity = opportunity;
        this.description = description;
        this.amount = amount;
        this.quoteDate = quoteDate;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Opportunity getOpportunity() {
        return opportunity;
    }

    public void setOpportunity(Opportunity opportunity) {
        this.opportunity = opportunity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDateTime getQuoteDate() {
        return quoteDate;
    }

    public void setQuoteDate(LocalDateTime quoteDate) {
        this.quoteDate = quoteDate;
    }

    @Override
    public String toString() {
        return "Quote [id=" + id + ", opportunity=" + opportunity + ", description=" + description + ", amount="
                + amount + ", quoteDate=" + quoteDate + "]";
    }

}