package com.example.sales_service.Service;

import com.example.sales_service.Entity.SalesTarget;
import com.example.sales_service.Repository.SalesTargetRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SalesTargetService {
    @Autowired
    private SalesTargetRepository salesTargetRepository;

    public List<SalesTarget> findAll() {
        return salesTargetRepository.findAll();
    }

    public SalesTarget findById(Long id) {
        return salesTargetRepository.findById(id).orElse(null);
    }

    public SalesTarget save(SalesTarget salesTarget) {
        return salesTargetRepository.save(salesTarget);
    }

    public void deleteById(Long id) {
        salesTargetRepository.deleteById(id);
    }

    public SalesTarget updateSalesTarget (Long id, SalesTarget salesTargetDeatiles){
        Optional<SalesTarget> salesTargetOptional =salesTargetRepository.findById(id);

        if(salesTargetOptional.isPresent()){
            SalesTarget salesTarget = salesTargetOptional.get();
            salesTarget.setSalesperson(salesTargetDeatiles.getSalesperson());
            salesTarget.setTargetAmount(salesTargetDeatiles.getTargetAmount());
            salesTarget.setStartDate(salesTargetDeatiles.getStartDate());
            salesTarget.setEndDate(salesTargetDeatiles.getEndDate());
            salesTarget.setOpportunity(salesTargetDeatiles.getOpportunity());

            return salesTargetRepository.save(salesTarget);
        }
        else{
            return null;
        }
    }
}
