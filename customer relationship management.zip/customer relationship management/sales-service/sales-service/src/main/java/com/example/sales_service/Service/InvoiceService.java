package com.example.sales_service.Service;

import com.example.sales_service.Entity.Invoice;
import com.example.sales_service.Repository.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InvoiceService {
    @Autowired
    private InvoiceRepository invoiceRepository;

    public List<Invoice> findAll() {
        return invoiceRepository.findAll();
    }

    public Invoice findById(Long id) {
        return invoiceRepository.findById(id).orElse(null);
    }

    public Invoice save(Invoice invoice) {
        return invoiceRepository.save(invoice);
    }

    public void deleteById(Long id) {
        invoiceRepository.deleteById(id);
    }
    public Invoice updateInvoice (Long id, Invoice invoiceDeatiles){
        Optional<Invoice> invoiceOptional = invoiceRepository.findById(id);

        if(invoiceOptional.isPresent()){
            Invoice invoice = invoiceOptional.get();
            invoice.setAmountDue(invoiceDeatiles.getAmountDue());
            invoice.setDueDate(invoiceDeatiles.getDueDate());
            invoice.setPaid(false);
            invoice.setOpportunity(invoiceDeatiles.getOpportunity());
            return invoiceRepository.save(invoice);
        }
        else{
            return null;
        }


    }
}
