package com.example.sales_service.Repository;

import com.example.sales_service.Entity.Quote;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QuoteRepository extends JpaRepository<Quote, Long> {}
