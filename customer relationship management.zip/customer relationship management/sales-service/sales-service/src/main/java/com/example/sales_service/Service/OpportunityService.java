package com.example.sales_service.Service;

import com.example.sales_service.Entity.Opportunity;
import com.example.sales_service.Repository.OpportunityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class OpportunityService {
    @Autowired
    private OpportunityRepository opportunityRepository;

    public List<Opportunity> findAll() {
        return opportunityRepository.findAll();
    }

    public Opportunity findById(Long id) {
        return opportunityRepository.findById(id).orElse(null);
    }

    public Opportunity save(Opportunity opportunity) {
        return opportunityRepository.save(opportunity);
    }

    public void deleteById(Long id) {
        opportunityRepository.deleteById(id);
    }
    public Opportunity updateOpportunity (Long id, Opportunity opportunityDeatiles){
        Optional<Opportunity> opportunityOptional =opportunityRepository.findById(id);

        if(opportunityOptional.isPresent()){

            Opportunity opportunity = opportunityOptional.get();
            opportunity.setName(opportunityDeatiles.getName());
            opportunity.setDescription(opportunityDeatiles.getDescription());
            opportunity.setCreationDate(opportunityDeatiles.getCreationDate());
            opportunity.setAssignedTo(opportunityDeatiles.getAssignedTo());
            opportunity.setQuotes(opportunityDeatiles.getQuotes());
            opportunity.setOrders(opportunityDeatiles.getOrders());
            opportunity.setInvoices(opportunityDeatiles.getInvoices());
            opportunity.setProducts(opportunityDeatiles.getProducts());
            opportunity.setSalesTargets(opportunityDeatiles.getSalesTargets());
            return opportunityRepository.save(opportunity);

        }
        else{
            return null;
        }
    }
}
