package com.example.sales_service.Entity;

import java.time.LocalDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;



@Entity
public class Opportunity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;
    private LocalDateTime creationDate;
    private String assignedTo;

    @OneToMany(mappedBy = "opportunity", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("opportunity")
    @JsonManagedReference
    private List<Quote> quotes;

    @OneToMany(mappedBy = "opportunity", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("opportunity")
    @JsonManagedReference
    private List<Order> orders;

    @OneToMany(mappedBy = "opportunity", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("opportunity")
    @JsonManagedReference
    private List<Invoice> invoices;

    @OneToMany(mappedBy = "opportunity", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("opportunity")
    @JsonManagedReference
    private List<Product> products;

    @OneToMany(mappedBy = "opportunity", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("opportunity")
    @JsonManagedReference
    private List<SalesTarget> salesTargets;


    public Opportunity() {}


    public Opportunity(Long id, String name, String description, LocalDateTime creationDate, String assignedTo,
            List<Quote> quotes, List<Order> orders, List<Invoice> invoices, List<Product> products,
            List<SalesTarget> salesTargets) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.creationDate = creationDate;
        this.assignedTo = assignedTo;
        this.quotes = quotes;
        this.orders = orders;
        this.invoices = invoices;
        this.products = products;
        this.salesTargets = salesTargets;
    }


    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public LocalDateTime getCreationDate() {
        return creationDate;
    }
    public void setCreationDate(LocalDateTime creationDate) {
        this.creationDate = creationDate;
    }
    public String getAssignedTo() {
        return assignedTo;
    }
    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }
    public List<Quote> getQuotes() {
        return quotes;
    }
    public void setQuotes(List<Quote> quotes) {
        this.quotes = quotes;
    }
    public List<Order> getOrders() {
        return orders;
    }
    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }
    public List<Invoice> getInvoices() {
        return invoices;
    }
    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
    }
    public List<Product> getProducts() {
        return products;
    }
    public void setProducts(List<Product> products) {
        this.products = products;
    }
    public List<SalesTarget> getSalesTargets() {
        return salesTargets;
    }
    public void setSalesTargets(List<SalesTarget> salesTargets) {
        this.salesTargets = salesTargets;
    }
    @Override
    public String toString() {
        return "Opportunity [id=" + id + ", name=" + name + ", description=" + description + ", creationDate="
                + creationDate + ", assignedTo=" + assignedTo + ", quotes=" + quotes + ", orders=" + orders
                + ", invoices=" + invoices + ", products=" + products + ", salesTargets=" + salesTargets + "]";
    }
}