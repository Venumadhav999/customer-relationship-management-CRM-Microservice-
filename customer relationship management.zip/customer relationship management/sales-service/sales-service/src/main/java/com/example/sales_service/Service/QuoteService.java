package com.example.sales_service.Service;

import com.example.sales_service.Entity.Quote;
import com.example.sales_service.Repository.QuoteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class QuoteService {
    @Autowired
    private QuoteRepository quoteRepository;

    public List<Quote> findAll() {
        return quoteRepository.findAll();
    }

    public Quote findById(Long id) {
        return quoteRepository.findById(id).orElse(null);
    }

    public Quote save(Quote quote) {
        return quoteRepository.save(quote);
    }

    public void deleteById(Long id) {
        quoteRepository.deleteById(id);
    }
    public Quote updaQuote (Long id, Quote quoteDeatiles){
        Optional<Quote> quoteOptional = quoteRepository.findById(id);

        if(quoteOptional.isPresent()){
            Quote quote = quoteOptional.get();
            quote.setOpportunity(quoteDeatiles.getOpportunity());
            quote.setDescription(quoteDeatiles.getDescription());
            quote.setAmount(quoteDeatiles.getAmount());
            quote.setQuoteDate(quoteDeatiles.getQuoteDate());
           
            return quoteRepository.save(quote);
        }
        else{
            return null;
        }
    }
}
