package com.example.sales_service.Repository;

import com.example.sales_service.Entity.SalesTarget;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesTargetRepository extends JpaRepository<SalesTarget, Long> {}
