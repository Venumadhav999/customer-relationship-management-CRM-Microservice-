package com.example.sales_service.Entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;


@Entity
public class SalesTarget {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String salesperson;
    private double targetAmount;
    private LocalDateTime startDate;
    private LocalDateTime endDate;
    private String description;
    private double amount;
    private LocalDateTime quoteDate;


    @ManyToOne
    @JsonBackReference
    private Opportunity opportunity;

    public SalesTarget() {}

    public SalesTarget(Long id, String salesperson, double targetAmount, LocalDateTime startDate, LocalDateTime endDate,
            String description, double amount, LocalDateTime quoteDate, Opportunity opportunity) {
        this.id = id;
        this.salesperson = salesperson;
        this.targetAmount = targetAmount;
        this.startDate = startDate;
        this.endDate = endDate;
        this.description = description;
        this.amount = amount;
        this.quoteDate = quoteDate;
        this.opportunity = opportunity;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSalesperson() {
        return salesperson;
    }

    public void setSalesperson(String salesperson) {
        this.salesperson = salesperson;
    }

    public double getTargetAmount() {
        return targetAmount;
    }

    public void setTargetAmount(double targetAmount) {
        this.targetAmount = targetAmount;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate(LocalDateTime startDate) {
        this.startDate = startDate;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(LocalDateTime endDate) {
        this.endDate = endDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDateTime getQuoteDate() {
        return quoteDate;
    }

    public void setQuoteDate(LocalDateTime quoteDate) {
        this.quoteDate = quoteDate;
    }

    public Opportunity getOpportunity() {
        return opportunity;
    }

    public void setOpportunity(Opportunity opportunity) {
        this.opportunity = opportunity;
    }

    @Override
    public String toString() {
        return "SalesTarget [id=" + id + ", salesperson=" + salesperson + ", targetAmount=" + targetAmount
                + ", startDate=" + startDate + ", endDate=" + endDate + ", description=" + description + ", amount="
                + amount + ", quoteDate=" + quoteDate + ", opportunity=" + opportunity + "]";
    }

}