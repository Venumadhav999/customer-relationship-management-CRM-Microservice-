package com.example.sales_service.Service;

import com.example.sales_service.Entity.Order;
import com.example.sales_service.Repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderService {
    @Autowired
    private OrderRepository orderRepository;

    public List<Order> findAll() {
        return orderRepository.findAll();
    }

    public Order findById(Long id) {
        return orderRepository.findById(id).orElse(null);
    }

    public Order save(Order order) {
        return orderRepository.save(order);
    }

    public void deleteById(Long id) {
        orderRepository.deleteById(id);
    }

    public Order updateOrder (Long id, Order orderDeatiles){
        Optional<Order> orderOptional =orderRepository.findById(id);

        if(orderOptional.isPresent()){
            Order order = orderOptional.get();
            order.setOpportunity(orderDeatiles.getOpportunity());
            order.setProduct(orderDeatiles.getProduct());
            order.setQuantity(orderDeatiles.getQuantity());
            order.setTotalPrice(orderDeatiles.getTotalPrice());
            order.setOrderDate(orderDeatiles.getOrderDate());
           
            return orderRepository.save(order);
        }
        else{
            return null;
        }
    }
}
