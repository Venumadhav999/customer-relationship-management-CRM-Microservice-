package com.example.sales_service.Controller;

import com.example.sales_service.Entity.SalesTarget;
import com.example.sales_service.Service.SalesTargetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/salesTargets")
public class SalesTargetController {
    @Autowired
    private SalesTargetService salesTargetService;

    @GetMapping
    public List<SalesTarget> findAll() {
        return salesTargetService.findAll();
    }

    @GetMapping("/{id}")
    public SalesTarget findById(@PathVariable Long id) {
        return salesTargetService.findById(id);
    }

    @PostMapping
    public SalesTarget save(@RequestBody SalesTarget salesTarget) {
        return salesTargetService.save(salesTarget);
    }

   

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        salesTargetService.deleteById(id);
    }
}
