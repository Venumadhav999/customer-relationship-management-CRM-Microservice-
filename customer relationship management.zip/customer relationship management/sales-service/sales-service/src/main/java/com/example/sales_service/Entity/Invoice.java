package com.example.sales_service.Entity;

import java.time.LocalDateTime;
import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

@Entity
@Table(name = "`invoice`")
public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private double amountDue;
    private LocalDateTime dueDate;
    private boolean paid;

    @ManyToOne
    @JsonBackReference
    private Opportunity opportunity;

    public Invoice() {}

    public Invoice(Long id, double amountDue, LocalDateTime dueDate, boolean paid, Opportunity opportunity) {
        this.id = id;
        this.amountDue = amountDue;
        this.dueDate = dueDate;
        this.paid = paid;
        this.opportunity = opportunity;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public double getAmountDue() {
        return amountDue;
    }

    public void setAmountDue(double amountDue) {
        this.amountDue = amountDue;
    }

    public LocalDateTime getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDateTime dueDate) {
        this.dueDate = dueDate;
    }

    public boolean isPaid() {
        return paid;
    }

    public void setPaid(boolean paid) {
        this.paid = paid;
    }

    public Opportunity getOpportunity() {
        return opportunity;
    }

    public void setOpportunity(Opportunity opportunity) {
        this.opportunity = opportunity;
    }

    @Override
    public String toString() {
        return "Invoice [id=" + id + ", amountDue=" + amountDue + ", dueDate=" + dueDate + ", paid=" + paid
                + ", opportunity=" + opportunity + "]";
    }

}