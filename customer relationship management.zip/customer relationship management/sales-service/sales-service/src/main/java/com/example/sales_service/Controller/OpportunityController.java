package com.example.sales_service.Controller;

import com.example.sales_service.Entity.Opportunity;
import com.example.sales_service.Service.OpportunityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/opportunities")
public class OpportunityController {
    @Autowired
    private OpportunityService opportunityService;

    @GetMapping
    public List<Opportunity> findAll() {
        return opportunityService.findAll();
    }

    @GetMapping("/{id}")
    public Opportunity findById(@PathVariable Long id) {
        return opportunityService.findById(id);
    }

    @PostMapping
    public Opportunity save(@RequestBody Opportunity opportunity) {
        return opportunityService.save(opportunity);
    }

    @PutMapping("/{id}")
    public Opportunity updateOpportunity(@PathVariable Long id, @RequestBody Opportunity opportunity) {
        return opportunityService.updateOpportunity(id, opportunity);
    }

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        opportunityService.deleteById(id);
    }
}
