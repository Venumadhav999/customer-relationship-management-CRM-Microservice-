package com.example.sales_service.Controller;

import com.example.sales_service.Entity.Quote;
import com.example.sales_service.Service.QuoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/quotes")
public class QuoteController {
    @Autowired
    private QuoteService quoteService;

    @GetMapping
    public List<Quote> findAll() {
        return quoteService.findAll();
    }

    @GetMapping("/{id}")
    public Quote findById(@PathVariable Long id) {
        return quoteService.findById(id);
    }

    @PostMapping
    public Quote save(@RequestBody Quote quote) {
        return quoteService.save(quote);
    }

   

    @DeleteMapping("/{id}")
    public void deleteById(@PathVariable Long id) {
        quoteService.deleteById(id);
    }
}
