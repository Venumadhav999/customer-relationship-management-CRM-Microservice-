package com.example.customer_service.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.customer_service.Entity.Activity;
import com.example.customer_service.Repository.ActivityRepository;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

@Service
public class ActivityService {

    @Autowired
    private SessionFactory sessionFactory;
    @Autowired
    private ActivityRepository activityRepository;

    public List<Activity> getAllActivities() {
        return activityRepository.findAll();
    }

    public Activity getActivityById(Long id) {
        return activityRepository.findById(id).orElse(null);
    }

    public Activity createActivity(Activity activity) {
        return activityRepository.save(activity);
    }

    public Activity updateActivity(Long id, Activity activityDetails) {
        Session session = sessionFactory.getCurrentSession(); 
        Activity activity = session.get(Activity.class, id); 
        if (activity != null) {
            // Update the activity details
            activity.setActivityType(activityDetails.getActivityType());
            activity.setSubject(activityDetails.getSubject());
            activity.setDescription(activityDetails.getDescription());
            activity.setDueDate(activityDetails.getDueDate());
            activity.setStatus(activityDetails.getStatus());
            activity.setCustomer(activityDetails.getCustomer());
            return activity;
        }
        return null;
    }

    public void deleteActivity(Long id) {
        activityRepository.deleteById(id);
    }
}
