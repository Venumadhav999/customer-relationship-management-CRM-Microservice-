package com.example.customer_service.Service;

import org.springframework.stereotype.Service;
import com.example.customer_service.Entity.Account;
import com.example.customer_service.Repository.AccountRepository;

import java.util.List;

@Service
public class AccountService {

    private final AccountRepository accountRepository;

    public AccountService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public List<Account> getAllAccounts() {
        return accountRepository.findAll();
    }

    public Account getAccountById(Long id) {
        return accountRepository.findById(id).orElse(null);
    }

    public Account createAccount(Account account) {
        return accountRepository.save(account);
    }

    public void deleteAccount(Long id) {
        accountRepository.deleteById(id);
    }

    public Account updateAccount(Long id, Account accountDetails) {
        Account existingAccount = accountRepository.findById(id).orElse(null);
        if (existingAccount != null) {
            existingAccount.setName(accountDetails.getName());
            existingAccount.setAddress(accountDetails.getAddress());
            existingAccount.setIndustry(accountDetails.getIndustry());
            existingAccount.setAccountNumber(accountDetails.getAccountNumber());
            existingAccount.setCustomer(accountDetails.getCustomer());
            return accountRepository.save(existingAccount);
        }
        return null;
    }
}
