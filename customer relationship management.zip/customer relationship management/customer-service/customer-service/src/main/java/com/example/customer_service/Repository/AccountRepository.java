package com.example.customer_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.customer_service.Entity.Account;


public interface AccountRepository extends JpaRepository<Account, Long> {
}
