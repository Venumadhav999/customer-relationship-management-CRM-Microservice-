package com.example.customer_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.customer_service.Entity.Case;

public interface CaseRepository extends JpaRepository<Case, Long> {
}

