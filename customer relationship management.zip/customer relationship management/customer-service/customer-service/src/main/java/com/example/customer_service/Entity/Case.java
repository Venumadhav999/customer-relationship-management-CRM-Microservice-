package com.example.customer_service.Entity;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "`case`")
public class Case {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "`case_number`")
    private String caseNumber;
    private String subject;
    private String description;
    private String status;
    private String priority;
    private String resolution;
   
    @ManyToOne
    @JsonBackReference
    private Customer customer;

    // Default constructor
    public Case() {
    }

    public Case(Long id, String caseNumber, String subject, String description, String status, String priority,
            String resolution, Customer customer) {
        this.id = id;
        this.caseNumber = caseNumber;
        this.subject = subject;
        this.description = description;
        this.status = status;
        this.priority = priority;
        this.resolution = resolution;
        this.customer = customer;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public String getResolution() {
        return resolution;
    }

    public void setResolution(String resolution) {
        this.resolution = resolution;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return "Case [id=" + id + ", caseNumber=" + caseNumber + ", subject=" + subject + ", description=" + description
                + ", status=" + status + ", priority=" + priority + ", resolution=" + resolution + ", customer="
                + customer + "]";
    }

}
