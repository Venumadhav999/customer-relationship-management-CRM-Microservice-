package com.example.customer_service.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.customer_service.Entity.Case;
import com.example.customer_service.Repository.CaseRepository;

@Service
public class CaseService {
    @Autowired
    private CaseRepository caseRepository;

    public List<Case> getAllCases() {
        return caseRepository.findAll();
    }

    public Case getCaseById(Long id) {
        return caseRepository.findById(id).orElse(null);
    }

    public Case createCase(Case caseEntity) {
        return caseRepository.save(caseEntity);
    }

    public Case updateCase(Long id, Case caseDetails) {
        Case caseEntity = caseRepository.findById(id).orElse(null);
        if (caseEntity != null) {
            caseEntity.setCaseNumber(caseDetails.getCaseNumber());
            caseEntity.setSubject(caseDetails.getSubject());
            caseEntity.setDescription(caseDetails.getDescription());
            caseEntity.setStatus(caseDetails.getStatus());
            caseEntity.setPriority(caseDetails.getPriority());
            caseEntity.setResolution(caseDetails.getResolution());
            caseEntity.setCustomer(caseDetails.getCustomer());
            return caseRepository.save(caseEntity);
        }
        return null;
    }

    public void deleteCase(Long id) {
        caseRepository.deleteById(id);
    }
}
