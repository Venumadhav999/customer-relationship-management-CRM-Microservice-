package com.example.customer_service.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String address;
    private String industry;
    private String accountNumber;

    @ManyToOne
    @JsonBackReference
    private Customer customer;

    // Constructors
    public Account() {
    }

    public Account(Long id, String name, String address, String industry, String accountNumber, Customer customer) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.industry = industry;
        this.accountNumber = accountNumber;
        this.customer = customer;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getIndustry() {
        return industry;
    }

    public void setIndustry(String industry) {
        this.industry = industry;
    }

    public String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return "Account [id=" + id + ", name=" + name + ", address=" + address + ", industry=" + industry
                + ", accountNumber=" + accountNumber + ", customer=" + customer + "]";
    }

}