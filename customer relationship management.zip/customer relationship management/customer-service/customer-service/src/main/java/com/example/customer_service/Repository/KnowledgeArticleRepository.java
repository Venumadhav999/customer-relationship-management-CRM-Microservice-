package com.example.customer_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.customer_service.Entity.KnowledgeArticle;

public interface KnowledgeArticleRepository extends JpaRepository<KnowledgeArticle, Long> {
}

