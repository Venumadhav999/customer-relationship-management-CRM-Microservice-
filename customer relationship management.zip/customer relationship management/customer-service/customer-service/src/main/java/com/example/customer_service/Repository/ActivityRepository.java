package com.example.customer_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.customer_service.Entity.Activity;

public interface ActivityRepository extends JpaRepository<Activity, Long> {
}
