package com.example.customer_service.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.customer_service.Entity.KnowledgeArticle;
import com.example.customer_service.Service.KnowledgeArticleService;

import java.util.List;

@RestController
@RequestMapping("/api/knowledge-articles")
public class KnowledgeArticleController {

    private static final Logger LOGGER = LoggerFactory.getLogger(KnowledgeArticleController.class);

    private final KnowledgeArticleService knowledgeArticleService;

    public KnowledgeArticleController(KnowledgeArticleService knowledgeArticleService) {
        this.knowledgeArticleService = knowledgeArticleService;
    }

    @PostMapping
    public ResponseEntity<KnowledgeArticle> createKnowledgeArticle(@RequestBody KnowledgeArticle knowledgeArticle) {
        LOGGER.info("Creating knowledge article: {}", knowledgeArticle);
        KnowledgeArticle createdKnowledgeArticle = knowledgeArticleService.createKnowledgeArticle(knowledgeArticle);
        return new ResponseEntity<>(createdKnowledgeArticle, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<KnowledgeArticle>> getAllKnowledgeArticles() {
        LOGGER.info("Fetching all knowledge articles");
        List<KnowledgeArticle> knowledgeArticles = knowledgeArticleService.getAllKnowledgeArticles();
        return new ResponseEntity<>(knowledgeArticles, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<KnowledgeArticle> getKnowledgeArticleById(@PathVariable Long id) {
        LOGGER.info("Fetching knowledge article by ID: {}", id);
        KnowledgeArticle knowledgeArticle = knowledgeArticleService.getKnowledgeArticleById(id);
        if (knowledgeArticle != null) {
            return new ResponseEntity<>(knowledgeArticle, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<KnowledgeArticle> updateKnowledgeArticle(@PathVariable Long id, @RequestBody KnowledgeArticle knowledgeArticleDetails) {
        LOGGER.info("Updating knowledge article with ID {}: {}", id, knowledgeArticleDetails);
        KnowledgeArticle updatedKnowledgeArticle = knowledgeArticleService.updateKnowledgeArticle(id, knowledgeArticleDetails);
        if (updatedKnowledgeArticle != null) {
            return new ResponseEntity<>(updatedKnowledgeArticle, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteKnowledgeArticle(@PathVariable Long id) {
        LOGGER.info("Deleting knowledge article with ID: {}", id);
        knowledgeArticleService.deleteKnowledgeArticle(id);
        return ResponseEntity.ok("Knowledge article deleted successfully");
    }
}
