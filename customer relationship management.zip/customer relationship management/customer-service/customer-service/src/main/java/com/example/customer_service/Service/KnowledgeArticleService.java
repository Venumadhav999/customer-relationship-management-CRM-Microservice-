package com.example.customer_service.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.customer_service.Entity.KnowledgeArticle;
import com.example.customer_service.Repository.KnowledgeArticleRepository;

@Service
public class KnowledgeArticleService {
    @Autowired
    private KnowledgeArticleRepository knowledgeArticleRepository;

    public List<KnowledgeArticle> getAllKnowledgeArticles() {
        return knowledgeArticleRepository.findAll();
    }

    public KnowledgeArticle getKnowledgeArticleById(Long id) {
        return knowledgeArticleRepository.findById(id).orElse(null);
    }

    public KnowledgeArticle createKnowledgeArticle(KnowledgeArticle knowledgeArticle) {
        return knowledgeArticleRepository.save(knowledgeArticle);
    }

    public KnowledgeArticle updateKnowledgeArticle(Long id, KnowledgeArticle knowledgeArticleDetails) {
        KnowledgeArticle knowledgeArticle = knowledgeArticleRepository.findById(id).orElse(null);
        if (knowledgeArticle != null) {
            knowledgeArticle.setTitle(knowledgeArticleDetails.getTitle());
            knowledgeArticle.setContent(knowledgeArticleDetails.getContent());
            knowledgeArticle.setKeywords(knowledgeArticleDetails.getKeywords());
            knowledgeArticle.setStatus(knowledgeArticleDetails.getStatus());
            knowledgeArticle.setCustomer(knowledgeArticleDetails.getCustomer());
            return knowledgeArticleRepository.save(knowledgeArticle);
        }
        return null;
    }

    public void deleteKnowledgeArticle(Long id) {
        knowledgeArticleRepository.deleteById(id);
    }
}
