package com.example.customer_service.Controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.example.customer_service.Entity.Case;
import com.example.customer_service.Service.CaseService;
import java.util.List;

@RestController
@RequestMapping("/api/cases")
public class CaseController {

    private static final Logger LOGGER = LoggerFactory.getLogger(CaseController.class);

    private final CaseService caseService;

    public CaseController(CaseService caseService) {
        this.caseService = caseService;
    }

    @PostMapping
    public ResponseEntity<Case> createCase(@RequestBody Case caseEntity) {
        LOGGER.info("Creating case: {}", caseEntity);
        Case createdCase = caseService.createCase(caseEntity);
        return new ResponseEntity<>(createdCase, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Case>> getAllCases() {
        LOGGER.info("Fetching all cases");
        List<Case> cases = caseService.getAllCases();
        return new ResponseEntity<>(cases, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Case> getCaseById(@PathVariable Long id) {
        LOGGER.info("Fetching case by ID: {}", id);
        Case caseEntity = caseService.getCaseById(id);
        if (caseEntity != null) {
            return new ResponseEntity<>(caseEntity, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Case> updateCase(@PathVariable Long id, @RequestBody Case caseDetails) {
        LOGGER.info("Updating case with ID {}: {}", id, caseDetails);
        Case updatedCase = caseService.updateCase(id, caseDetails);
        if (updatedCase != null) {
            return new ResponseEntity<>(updatedCase, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteCase(@PathVariable Long id) {
        LOGGER.info("Deleting case with ID: {}", id);
        caseService.deleteCase(id);
        return ResponseEntity.ok("Case deleted successfully");
    }
}
