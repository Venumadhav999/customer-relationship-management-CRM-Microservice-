package com.example.customer_service.Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String phone;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("customer")
    @JsonManagedReference
    private List<Account> accounts;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("customer")
    @JsonManagedReference
    private List<Case> cases;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("customer")
    @JsonManagedReference
    private List<Activity> activitys;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("customer")
    @JsonManagedReference
    private List<Contact> contacts;

    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("customer")
    @JsonManagedReference
    private List<KnowledgeArticle> knowledgeArticles;

    public Customer() {
    }

    public Customer(Long id, String name, String email, String phone, List<Account> accounts, List<Case> cases,
            List<Activity> activitys, List<Contact> contacts, List<KnowledgeArticle> knowledgeArticles) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.accounts = accounts;
        this.cases = cases;
        this.activitys = activitys;
        this.contacts = contacts;
        this.knowledgeArticles = knowledgeArticles;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public List<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

    public List<Case> getCases() {
        return cases;
    }

    public void setCases(List<Case> cases) {
        this.cases = cases;
    }

    public List<Activity> getActivitys() {
        return activitys;
    }

    public void setActivitys(List<Activity> activitys) {
        this.activitys = activitys;
    }

    public List<Contact> getContacts() {
        return contacts;
    }

    public void setContacts(List<Contact> contacts) {
        this.contacts = contacts;
    }

    public List<KnowledgeArticle> getKnowledgeArticles() {
        return knowledgeArticles;
    }

    public void setKnowledgeArticles(List<KnowledgeArticle> knowledgeArticles) {
        this.knowledgeArticles = knowledgeArticles;
    }

    @Override
    public String toString() {
        return "Customer [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone + ", accounts="
                + accounts + ", cases=" + cases + ", activitys=" + activitys + ", contacts=" + contacts
                + ", knowledgeArticles=" + knowledgeArticles + "]";
    }
    
}
