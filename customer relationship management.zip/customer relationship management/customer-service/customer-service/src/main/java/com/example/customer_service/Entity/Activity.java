package com.example.customer_service.Entity;
import jakarta.persistence.*;
import java.time.LocalDate;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "activity")
public class Activity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "activity_type")
    private String activityType;
    private String subject;
    private String description;

    @Column(name = "due_date")
    private LocalDate dueDate;
    private String status;

    @ManyToOne
    @JsonBackReference
    private Customer customer;

    // Default constructor
    public Activity() {
    }

    public Activity(Long id, String activityType, String subject, String description, LocalDate dueDate, String status,
            Customer customer) {
        this.id = id;
        this.activityType = activityType;
        this.subject = subject;
        this.description = description;
        this.dueDate = dueDate;
        this.status = status;
        this.customer = customer;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    @Override
    public String toString() {
        return "Activity [id=" + id + ", activityType=" + activityType + ", subject=" + subject + ", description="
                + description + ", dueDate=" + dueDate + ", status=" + status + ", customer=" + customer + "]";
    }

}