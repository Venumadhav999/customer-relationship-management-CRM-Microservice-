package com.example.lead_service.Controller;

import com.example.lead_service.Entity.LeadActivity;
import com.example.lead_service.Service.LeadActivityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lead-activities")
public class LeadActivityController {

    @Autowired
    private LeadActivityService leadActivityService;

    @GetMapping
    public List<LeadActivity> getAllLeadActivities() {
        return leadActivityService.getAllLeadActivities();
    }

    @GetMapping("/{id}")
    public ResponseEntity<LeadActivity> getLeadActivityById(@PathVariable Long id) {
        return leadActivityService.getLeadActivityById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public LeadActivity createLeadActivity(@RequestBody LeadActivity leadActivity) {
        return leadActivityService.createLeadActivity(leadActivity);
    }

    @PutMapping("/{id}")
    public ResponseEntity<LeadActivity> updateLeadActivity(@PathVariable Long id, @RequestBody LeadActivity leadActivityDetails) {
        LeadActivity updatedLeadActivity = leadActivityService.updateLeadActivity(id, leadActivityDetails);
        return updatedLeadActivity != null ? ResponseEntity.ok(updatedLeadActivity) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLeadActivity(@PathVariable Long id) {
        leadActivityService.deleteLeadActivity(id);
        return ResponseEntity.ok().build();
    }
}