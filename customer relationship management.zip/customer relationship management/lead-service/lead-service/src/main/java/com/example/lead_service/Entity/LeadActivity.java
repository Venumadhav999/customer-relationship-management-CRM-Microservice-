package com.example.lead_service.Entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
public class LeadActivity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String activityType;
    private LocalDateTime timestamp;
    private String description;
    private String createdBy;

    
    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "lead_id", nullable = false)
    private Lead lead;

    // Constructors
    public LeadActivity() { }

    public LeadActivity(Long id, String activityType, LocalDateTime timestamp, String description, String createdBy,
            Lead lead) {
        this.id = id;
        this.activityType = activityType;
        this.timestamp = timestamp;
        this.description = description;
        this.createdBy = createdBy;
        this.lead = lead;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Lead getLead() {
        return lead;
    }

    public void setLead(Lead lead) {
        this.lead = lead;
    }

    @Override
    public String toString() {
        return "LeadActivity [id=" + id + ", activityType=" + activityType + ", timestamp=" + timestamp
                + ", description=" + description + ", createdBy=" + createdBy + ", lead=" + lead + "]";
    }

}