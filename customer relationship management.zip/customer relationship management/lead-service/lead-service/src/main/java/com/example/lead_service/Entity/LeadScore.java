package com.example.lead_service.Entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
public class LeadScore {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private int score;
    private LocalDateTime lastScoreUpdate;

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "lead_id", nullable = false)
    private Lead lead;

    // Constructors
    public LeadScore() { }

    public LeadScore(Long id, String name, int score, LocalDateTime lastScoreUpdate, Lead lead) {
        this.id = id;
        this.name = name;
        this.score = score;
        this.lastScoreUpdate = lastScoreUpdate;
        this.lead = lead;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public LocalDateTime getLastScoreUpdate() {
        return lastScoreUpdate;
    }

    public void setLastScoreUpdate(LocalDateTime lastScoreUpdate) {
        this.lastScoreUpdate = lastScoreUpdate;
    }

    public Lead getLead() {
        return lead;
    }

    public void setLead(Lead lead) {
        this.lead = lead;
    }

    @Override
    public String toString() {
        return "LeadScore [id=" + id + ", name=" + name + ", score=" + score + ", lastScoreUpdate=" + lastScoreUpdate + ", lead=" + lead + "]";
    }
}
