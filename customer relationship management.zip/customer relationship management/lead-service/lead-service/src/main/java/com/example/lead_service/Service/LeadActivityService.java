package com.example.lead_service.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.lead_service.Entity.LeadActivity;
import com.example.lead_service.Repository.LeadActivityRepository;
import java.util.List;
import java.util.Optional;

@Service
public class LeadActivityService {

    @Autowired
    private LeadActivityRepository leadActivityRepository;

    public List<LeadActivity> getAllLeadActivities() {
        return leadActivityRepository.findAll();
    }

    public Optional<LeadActivity> getLeadActivityById(Long id) {
        return leadActivityRepository.findById(id);
    }

    public LeadActivity createLeadActivity(LeadActivity leadActivity) {
        return leadActivityRepository.save(leadActivity);
    }

    public LeadActivity updateLeadActivity(Long id, LeadActivity leadActivityDetails) {
        Optional<LeadActivity> leadActivityOptional = leadActivityRepository.findById(id);
        if (leadActivityOptional.isPresent()) {
            LeadActivity leadActivity = leadActivityOptional.get();
            leadActivity.setActivityType(leadActivityDetails.getActivityType());
            leadActivity.setTimestamp(leadActivityDetails.getTimestamp());
            leadActivity.setDescription(leadActivityDetails.getDescription());
            leadActivity.setCreatedBy(leadActivityDetails.getCreatedBy());
            return leadActivityRepository.save(leadActivity);
        } else {
            return null;
        }
    }

    public void deleteLeadActivity(Long id) {
        leadActivityRepository.deleteById(id);
    }
}
