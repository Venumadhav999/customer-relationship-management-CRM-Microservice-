package com.example.lead_service.Service;

import com.example.lead_service.Entity.LeadStatus;
import com.example.lead_service.Repository.LeadStatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LeadStatusService {

    @Autowired
    private LeadStatusRepository leadStatusRepository;

    public List<LeadStatus> getAllLeadStatuses() {
        return leadStatusRepository.findAll();
    }

    public Optional<LeadStatus> getLeadStatusById(Long id) {
        return leadStatusRepository.findById(id);
    }

    public LeadStatus createLeadStatus(LeadStatus leadStatus) {
        return leadStatusRepository.save(leadStatus);
    }

    public LeadStatus updateLeadStatus(Long id, LeadStatus leadStatusDetails) {
        Optional<LeadStatus> leadStatusOptional = leadStatusRepository.findById(id);
        if (leadStatusOptional.isPresent()) {
            LeadStatus leadStatus = leadStatusOptional.get();
            leadStatus.setName(leadStatusDetails.getName());
            leadStatus.setDescription(leadStatusDetails.getDescription());
            leadStatus.setLastContactDate(leadStatusDetails.getLastContactDate());
            leadStatus.setAssignedTo(leadStatusDetails.getAssignedTo());
            leadStatus.setLead(leadStatusDetails.getLead());
            return leadStatusRepository.save(leadStatus);
        } else {
            return null;
        }
    }

    public void deleteLeadStatus(Long id) {
        leadStatusRepository.deleteById(id);
    }
}
