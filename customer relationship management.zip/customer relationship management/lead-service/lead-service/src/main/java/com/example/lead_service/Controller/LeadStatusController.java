package com.example.lead_service.Controller;

import com.example.lead_service.Entity.LeadStatus;
import com.example.lead_service.Service.LeadStatusService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lead-statuses")
public class LeadStatusController {

    @Autowired
    private LeadStatusService leadStatusService;

    @GetMapping
    public List<LeadStatus> getAllLeadStatuses() {
        return leadStatusService.getAllLeadStatuses();
    }

    @GetMapping("/{id}")
    public ResponseEntity<LeadStatus> getLeadStatusById(@PathVariable Long id) {
        return leadStatusService.getLeadStatusById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public LeadStatus createLeadStatus(@RequestBody LeadStatus leadStatus) {
        return leadStatusService.createLeadStatus(leadStatus);
    }

    @PutMapping("/{id}")
    public ResponseEntity<LeadStatus> updateLeadStatus(@PathVariable Long id, @RequestBody LeadStatus leadStatusDetails) {
        LeadStatus updatedLeadStatus = leadStatusService.updateLeadStatus(id, leadStatusDetails);
        return updatedLeadStatus != null ? ResponseEntity.ok(updatedLeadStatus) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLeadStatus(@PathVariable Long id) {
        leadStatusService.deleteLeadStatus(id);
        return ResponseEntity.ok().build();
    }
}