package com.example.lead_service.Controller;

import com.example.lead_service.Entity.LeadSource;
import com.example.lead_service.Service.LeadSourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lead-sources")
public class LeadSourceController {

    @Autowired
    private LeadSourceService leadSourceService;

    @GetMapping
    public List<LeadSource> getAllLeadSources() {
        return leadSourceService.getAllLeadSources();
    }

    @GetMapping("/{id}")
    public ResponseEntity<LeadSource> getLeadSourceById(@PathVariable Long id) {
        return leadSourceService.getLeadSourceById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public LeadSource createLeadSource(@RequestBody LeadSource leadSource) {
        return leadSourceService.createLeadSource(leadSource);
    }

    @PutMapping("/{id}")
    public ResponseEntity<LeadSource> updateLeadSource(@PathVariable Long id, @RequestBody LeadSource leadSourceDetails) {
        LeadSource updatedLeadSource = leadSourceService.updateLeadSource(id, leadSourceDetails);
        return updatedLeadSource != null ? ResponseEntity.ok(updatedLeadSource) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLeadSource(@PathVariable Long id) {
        leadSourceService.deleteLeadSource(id);
        return ResponseEntity.ok().build();
    }
}