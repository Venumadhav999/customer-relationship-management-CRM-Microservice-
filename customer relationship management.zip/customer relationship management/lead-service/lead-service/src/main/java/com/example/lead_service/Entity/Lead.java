package com.example.lead_service.Entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;

@Entity
@Table(name = "`lead`")
public class Lead {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotEmpty(message = "Name is required")
    private String name;

    @Email(message = "Email should be valid")
    private String email;

    private String phone;
    private String company;
    private String jobTitle;
    private LocalDateTime createdDate;
    private LocalDateTime updatedDate;

    @OneToMany(mappedBy = "lead", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("lead")
    @JsonManagedReference
    private List<LeadSource> leadSource;

    @OneToMany(mappedBy = "lead", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("lead")
    @JsonManagedReference
    private List<LeadStatus> leadStatus;

    @OneToMany(mappedBy = "lead", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("lead")
    @JsonManagedReference
    private List<LeadScore> leadScore;

    @OneToMany(mappedBy = "lead", cascade = CascadeType.ALL)
    @JsonIgnoreProperties("lead")
    @JsonManagedReference
    private List<LeadActivity> leadActivities;

    // Constructors
    public Lead() {
        this.createdDate = LocalDateTime.now();
        this.updatedDate = LocalDateTime.now();
        this.leadScore = new ArrayList<>();
    }

    public Lead(Long id, @NotEmpty(message = "Name is required") String name,
            @Email(message = "Email should be valid") String email, String phone, String company, String jobTitle,
            LocalDateTime createdDate, LocalDateTime updatedDate, List<LeadSource> leadSource,
            List<LeadStatus> leadStatus, List<LeadScore> leadScore, List<LeadActivity> leadActivities) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.company = company;
        this.jobTitle = jobTitle;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
        this.leadSource = leadSource;
        this.leadStatus = leadStatus;
        this.leadScore = leadScore;
        this.leadActivities = leadActivities;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getJobTitle() {
        return jobTitle;
    }

    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(LocalDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public List<LeadSource> getLeadSource() {
        return leadSource;
    }

    public void setLeadSource(List<LeadSource> leadSource) {
        this.leadSource = leadSource;
    }

    public List<LeadStatus> getLeadStatus() {
        return leadStatus;
    }

    public void setLeadStatus(List<LeadStatus> leadStatus) {
        this.leadStatus = leadStatus;
    }

    public List<LeadScore> getLeadScore() {
        return leadScore;
    }

    public void setLeadScore(List<LeadScore> leadScore) {
        this.leadScore = leadScore;
    }

    public List<LeadActivity> getLeadActivities() {
        return leadActivities;
    }

    public void setLeadActivities(List<LeadActivity> leadActivities) {
        this.leadActivities = leadActivities;
    }

    @Override
    public String toString() {
        return "Lead [id=" + id + ", name=" + name + ", email=" + email + ", phone=" + phone + ", company=" + company
                + ", jobTitle=" + jobTitle + ", createdDate=" + createdDate + ", updatedDate=" + updatedDate
                + ", leadSource=" + leadSource + ", leadStatus=" + leadStatus + ", leadScore=" + leadScore
                + ", leadActivities=" + leadActivities + "]";
    }
    

}