package com.example.lead_service.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.lead_service.Entity.Lead;
import com.example.lead_service.Repository.LeadRepository;
import java.util.List;
import java.util.Optional;

@Service
public class LeadService {

    @Autowired
    private LeadRepository leadRepository;

    public List<Lead> getAllLeads() {
        return leadRepository.findAll();
    }
    

    public Optional<Lead> getLeadById(Long id) {
        return leadRepository.findById(id);
    }

    public Lead createLead(Lead lead) {
        return leadRepository.save(lead);
    }

    public Lead updateLead(Long id, Lead leadDetails) {
        Optional<Lead> leadOptional = leadRepository.findById(id);
        if (leadOptional.isPresent()) {
            Lead lead = leadOptional.get();
            lead.setName(leadDetails.getName());
            lead.setEmail(leadDetails.getEmail());
            lead.setPhone(leadDetails.getPhone());
            lead.setCompany(leadDetails.getCompany());
            lead.setJobTitle(leadDetails.getJobTitle());
            lead.setCreatedDate(leadDetails.getCreatedDate());
            lead.setUpdatedDate(leadDetails.getUpdatedDate());
            lead.setLeadSource(leadDetails.getLeadSource());
            lead.setLeadStatus(leadDetails.getLeadStatus());
            lead.setLeadScore(leadDetails.getLeadScore());
            lead.setLeadActivities(leadDetails.getLeadActivities());
            return leadRepository.save(lead);
        } else {
            return null;
        }
    }

    public void deleteLead(Long id) {
        leadRepository.deleteById(id);
    }
}
