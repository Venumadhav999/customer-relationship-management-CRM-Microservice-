package com.example.lead_service.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
public class LeadSource {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "lead_id", nullable = false)
    private Lead lead;

    // Constructors
    public LeadSource() { }

    public LeadSource(Long id, String name, String description, Lead lead) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.lead = lead;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Lead getLead() {
        return lead;
    }

    public void setLead(Lead lead) {
        this.lead = lead;
    }

    @Override
    public String toString() {
        return "LeadSource [id=" + id + ", name=" + name + ", description=" + description + ", lead=" + lead + "]";
    }
}
