package com.example.lead_service.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.lead_service.Entity.LeadScore;

@Repository
public interface LeadScoreRepository extends JpaRepository<LeadScore, Long> {
}

