package com.example.lead_service.Controller;

import com.example.lead_service.Entity.LeadScore;
import com.example.lead_service.Service.LeadScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/lead-scores")
public class LeadScoreController {

    @Autowired
    private LeadScoreService leadScoreService;

    @GetMapping
    public List<LeadScore> getAllLeadScores() {
        return leadScoreService.getAllLeadScores();
    }

    @GetMapping("/{id}")
    public ResponseEntity<LeadScore> getLeadScoreById(@PathVariable Long id) {
        return leadScoreService.getLeadScoreById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public LeadScore createLeadScore(@RequestBody LeadScore leadScore) {
        return leadScoreService.createLeadScore(leadScore);
    }

    @PutMapping("/{id}")
    public ResponseEntity<LeadScore> updateLeadScore(@PathVariable Long id, @RequestBody LeadScore leadScoreDetails) {
        LeadScore updatedLeadScore = leadScoreService.updateLeadScore(id, leadScoreDetails);
        return updatedLeadScore != null ? ResponseEntity.ok(updatedLeadScore) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteLeadScore(@PathVariable Long id) {
        leadScoreService.deleteLeadScore(id);
        return ResponseEntity.ok().build();
    }
}