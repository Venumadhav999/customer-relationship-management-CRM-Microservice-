package com.example.lead_service.Service;

import com.example.lead_service.Entity.LeadSource;
import com.example.lead_service.Repository.LeadSourceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LeadSourceService {

    @Autowired
    private LeadSourceRepository leadSourceRepository;

    public List<LeadSource> getAllLeadSources() {
        return leadSourceRepository.findAll();
    }

    public Optional<LeadSource> getLeadSourceById(Long id) {
        return leadSourceRepository.findById(id);
    }

    public LeadSource createLeadSource(LeadSource leadSource) {
        return leadSourceRepository.save(leadSource);
    }

    public LeadSource updateLeadSource(Long id, LeadSource leadSourceDetails) {
        Optional<LeadSource> leadSourceOptional = leadSourceRepository.findById(id);
        if (leadSourceOptional.isPresent()) {
            LeadSource leadSource = leadSourceOptional.get();
            leadSource.setName(leadSourceDetails.getName());
            leadSource.setDescription(leadSourceDetails.getDescription());
            leadSource.setLead(leadSourceDetails.getLead());
            return leadSourceRepository.save(leadSource);
        } else {
            return null;
        }
    }

    public void deleteLeadSource(Long id) {
        leadSourceRepository.deleteById(id);
    }
}
