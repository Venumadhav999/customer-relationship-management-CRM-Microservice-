package com.example.lead_service.Entity;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
public class LeadStatus {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String description;
    private LocalDateTime lastContactDate;
    private String assignedTo;

    
    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "lead_id", nullable = false)
    private Lead lead;

    // Constructors
    public LeadStatus() { }

    public LeadStatus(Long id, String name, String description, LocalDateTime lastContactDate, String assignedTo, Lead lead) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.lastContactDate = lastContactDate;
        this.assignedTo = assignedTo;
        this.lead = lead;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public LocalDateTime getLastContactDate() {
        return lastContactDate;
    }

    public void setLastContactDate(LocalDateTime lastContactDate) {
        this.lastContactDate = lastContactDate;
    }

    public String getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }

    public Lead getLead() {
        return lead;
    }

    public void setLead(Lead lead) {
        this.lead = lead;
    }

    @Override
    public String toString() {
        return "LeadStatus [id=" + id + ", name=" + name + ", description=" + description + ", lastContactDate=" + lastContactDate + ", assignedTo=" + assignedTo + ", lead=" + lead + "]";
    }
}
