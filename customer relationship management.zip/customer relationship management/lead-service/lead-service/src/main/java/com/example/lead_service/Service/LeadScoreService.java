package com.example.lead_service.Service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.lead_service.Entity.LeadScore;
import com.example.lead_service.Repository.LeadScoreRepository;

import java.util.List;
import java.util.Optional;

@Service
public class LeadScoreService {

    @Autowired
    private LeadScoreRepository leadScoreRepository;

    public List<LeadScore> getAllLeadScores() {
        return leadScoreRepository.findAll();
    }

    public Optional<LeadScore> getLeadScoreById(Long id) {
        return leadScoreRepository.findById(id);
    }

    public LeadScore createLeadScore(LeadScore leadScore) {
        return leadScoreRepository.save(leadScore);
    }

    public LeadScore updateLeadScore(Long id, LeadScore leadScoreDetails) {
        Optional<LeadScore> leadScoreOptional = leadScoreRepository.findById(id);
        if (leadScoreOptional.isPresent()) {
            LeadScore leadScore = leadScoreOptional.get();
            leadScore.setName(leadScoreDetails.getName());
            leadScore.setScore(leadScoreDetails.getScore());
            leadScore.setLastScoreUpdate(leadScoreDetails.getLastScoreUpdate());
            leadScore.setLead(leadScoreDetails.getLead());
            return leadScoreRepository.save(leadScore);
        } else {
            return null;
        }
    }

    public void deleteLeadScore(Long id) {
        leadScoreRepository.deleteById(id);
    }
}
