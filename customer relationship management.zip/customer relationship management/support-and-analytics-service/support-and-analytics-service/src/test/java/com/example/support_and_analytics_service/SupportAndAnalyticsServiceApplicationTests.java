package com.example.support_and_analytics_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SupportAndAnalyticsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
