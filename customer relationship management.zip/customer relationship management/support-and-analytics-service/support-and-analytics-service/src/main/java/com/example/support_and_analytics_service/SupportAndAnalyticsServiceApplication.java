package com.example.support_and_analytics_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class SupportAndAnalyticsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SupportAndAnalyticsServiceApplication.class, args);
	}

}
