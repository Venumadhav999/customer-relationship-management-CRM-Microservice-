package com.example.support_and_analytics_service.Controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.support_and_analytics_service.Client.CustomerClient;
import com.example.support_and_analytics_service.Client.SurveyClient;
import com.example.support_and_analytics_service.DTO.SurveyDataResponseDTO;
import com.example.support_and_analytics_service.Entity.Customer;
import com.example.support_and_analytics_service.Entity.Survey;
import com.example.support_and_analytics_service.Entity.SurveyResponse;
import com.example.support_and_analytics_service.Service.SurveyResponseService;

@RestController
@RequestMapping("/api/surveyResponses")
public class SurveyResponseController {

    @Autowired
    private SurveyResponseService surveyResponseService;

    @Autowired
    private CustomerClient customerClient;

    @Autowired
    private SurveyClient surveyClient;

    public SurveyResponseController(SurveyResponseService surveyResponseService, CustomerClient customerClient, SurveyClient surveyClient) {
        this.surveyResponseService = surveyResponseService;
        this.customerClient = customerClient;
        this.surveyClient = surveyClient;
    }

    @GetMapping
    public List<SurveyDataResponseDTO> getAllSurveyResponses() {
        List<SurveyResponse> surveyResponses = surveyResponseService.getAllSurveyResponses();
        return surveyResponses.stream()
                .map(response -> {
                    Customer customer = customerClient.getCustomerById(Long.parseLong(response.getCustomerId()));
                    Survey survey = surveyClient.getSurveyById(Long.parseLong(response.getSurveyId()));
                    return new SurveyDataResponseDTO(response, customer, survey);
                })
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<SurveyDataResponseDTO> getSurveyResponseById(@PathVariable Long id) {
        Optional<SurveyResponse> surveyResponse = surveyResponseService.getByIdSurveyResponses(id);
        if (surveyResponse.isPresent()) {
            Customer customer = customerClient.getCustomerById(Long.parseLong(surveyResponse.get().getCustomerId()));
            Survey survey = surveyClient.getSurveyById(Long.parseLong(surveyResponse.get().getSurveyId()));
            return new ResponseEntity<>(new SurveyDataResponseDTO(surveyResponse.get(), customer, survey), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<SurveyDataResponseDTO> createSurveyResponse(@RequestBody SurveyResponse surveyResponse) {
        try {
            Customer customer = customerClient.getCustomerById(Long.parseLong(surveyResponse.getCustomerId()));
            if (customer == null) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }

            Survey survey = surveyClient.getSurveyById(Long.parseLong(surveyResponse.getSurveyId()));
            if (survey == null) {
                return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
            }

            SurveyResponse createdResponse = surveyResponseService.createSurveyResponse(surveyResponse);
            return new ResponseEntity<>(new SurveyDataResponseDTO(createdResponse, customer, survey), HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<SurveyDataResponseDTO> updateSurveyResponse(@PathVariable Long id, @RequestBody SurveyResponse surveyResponseDetails) {
        SurveyResponse updatedResponse = surveyResponseService.updateSurveyResponse(id, surveyResponseDetails);
        if (updatedResponse != null) {
            Customer customer = customerClient.getCustomerById(Long.parseLong(updatedResponse.getCustomerId()));
            Survey survey = surveyClient.getSurveyById(Long.parseLong(updatedResponse.getSurveyId()));
            return new ResponseEntity<>(new SurveyDataResponseDTO(updatedResponse, customer, survey), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSurveyResponse(@PathVariable Long id) {
        surveyResponseService.deleteSurveyResponse(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
