package com.example.support_and_analytics_service.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.support_and_analytics_service.Entity.SurveyResponse;
import com.example.support_and_analytics_service.Repository.SurveyResponseRepository;

@Service
public class SurveyResponseService {

    @Autowired
    private SurveyResponseRepository surveyResponseRepository;

    public List<SurveyResponse>  getAllSurveyResponses(){
        return surveyResponseRepository.findAll();
    }

    public Optional<SurveyResponse> getByIdSurveyResponses(Long id){
        return surveyResponseRepository.findById(id);

    }

    public SurveyResponse createSurveyResponse(SurveyResponse surveyResponse){
        return surveyResponseRepository.save(surveyResponse);
    }
    public void deleteSurveyResponse (Long id){
        surveyResponseRepository.deleteById(id);
    }

    public SurveyResponse updateSurveyResponse(Long id, SurveyResponse surveyResponseDeatiles){
        Optional<SurveyResponse> surveyResponseOptional = surveyResponseRepository.findById(id);

        if(surveyResponseOptional.isPresent()){
            SurveyResponse surveyResponse = surveyResponseOptional.get();
            surveyResponse.setSurveyId(surveyResponseDeatiles.getSurveyId());
            surveyResponse.setCustomerId(surveyResponseDeatiles.getCustomerId());
            surveyResponse.setResponse(surveyResponseDeatiles.getResponse());

           return surveyResponseRepository.save(surveyResponse);
        }
        else{
            return null;
        }
    }
    
}


