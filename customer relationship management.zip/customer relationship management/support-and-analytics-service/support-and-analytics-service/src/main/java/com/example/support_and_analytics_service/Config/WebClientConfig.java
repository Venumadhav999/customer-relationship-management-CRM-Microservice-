package com.example.support_and_analytics_service.Config;

import com.example.support_and_analytics_service.Client.CustomerClient;
import com.example.support_and_analytics_service.Client.SurveyClient;
import org.springframework.cloud.client.loadbalancer.reactive.LoadBalancedExchangeFilterFunction;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.support.WebClientAdapter;
import org.springframework.web.service.invoker.HttpServiceProxyFactory;

@Configuration
public class WebClientConfig {
    private final LoadBalancedExchangeFilterFunction filterFunction;

    public WebClientConfig(LoadBalancedExchangeFilterFunction filterFunction) {
        this.filterFunction = filterFunction;
    }

    @Bean
    public WebClient customerWebClient() {
        return WebClient.builder()
                .baseUrl("http://customer-service")
                .filter(filterFunction)
                .build();
    }

    @Bean
    public WebClient surveyWebClient() {
        return WebClient.builder()
                .baseUrl("http://marketing-service")
                .filter(filterFunction)
                .build();
    }


    @Bean
    public CustomerClient customerClient() {
        HttpServiceProxyFactory httpServiceProxyFactory = HttpServiceProxyFactory
                .builderFor(WebClientAdapter.create(customerWebClient()))
                .build();
        return httpServiceProxyFactory.createClient(CustomerClient.class);
    }

    @Bean
    public SurveyClient surveyClient() {
        HttpServiceProxyFactory httpServiceProxyFactory = HttpServiceProxyFactory
                .builderFor(WebClientAdapter.create(surveyWebClient()))
                .build();
        return httpServiceProxyFactory.createClient(SurveyClient.class);
    }

}