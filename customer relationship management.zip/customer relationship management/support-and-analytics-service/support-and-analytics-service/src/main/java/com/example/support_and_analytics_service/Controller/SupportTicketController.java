package com.example.support_and_analytics_service.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.support_and_analytics_service.Entity.SupportTicket;
import com.example.support_and_analytics_service.Service.SupportTicketService;

@RestController
@RequestMapping("/api/supportTickets")
public class SupportTicketController {

    @Autowired
    private SupportTicketService supportTicketService;

    @GetMapping
    public List<SupportTicket> getAllSupportTickets() {
        return supportTicketService.getSupportTicketAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<SupportTicket> getSupportTicketById(@PathVariable Long id) {
        Optional<SupportTicket> supportTicket = supportTicketService.getSupportTicketById(id);
        if (supportTicket.isPresent()) {
            return new ResponseEntity<>(supportTicket.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<SupportTicket> createSupportTicket(@RequestBody SupportTicket supportTicket) {
        SupportTicket createdSupportTicket = supportTicketService.createSupportTicket(supportTicket);
        return new ResponseEntity<>(createdSupportTicket, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<SupportTicket> updateSupportTicket(@PathVariable Long id, @RequestBody SupportTicket supportTicketDetails) {
        SupportTicket updatedSupportTicket = supportTicketService.updateSupportTicket(id, supportTicketDetails);
        if (updatedSupportTicket != null) {
            return new ResponseEntity<>(updatedSupportTicket, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSupportTicket(@PathVariable Long id) {
        supportTicketService.deleteSupportTicket(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
