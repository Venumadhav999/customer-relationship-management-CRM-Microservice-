package com.example.support_and_analytics_service.Client;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.HttpExchange;

import com.example.support_and_analytics_service.Entity.Survey;

@HttpExchange
public interface SurveyClient {
    @GetExchange("/api/surveys/{id}")
    Survey getSurveyById(@PathVariable("id") Long id);
}