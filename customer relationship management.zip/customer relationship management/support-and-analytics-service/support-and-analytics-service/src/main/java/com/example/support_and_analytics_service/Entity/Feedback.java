package com.example.support_and_analytics_service.Entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;

@Entity
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerId;
    private String comments;
    private int rating;
    private LocalDateTime feedbackDate;

    // Default constructor
    public Feedback() {}

    // Parameterized constructor
    public Feedback(String customerId, String comments, int rating, LocalDateTime feedbackDate) {
        this.customerId = customerId;
        this.comments = comments;
        this.rating = rating;
        this.feedbackDate = feedbackDate;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public LocalDateTime getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(LocalDateTime feedbackDate) {
        this.feedbackDate = feedbackDate;
    }

    @Override
    public String toString() {
        return "Feedback{" +
                "id=" + id +
                ", customerId='" + customerId + '\'' +
                ", comments='" + comments + '\'' +
                ", rating=" + rating +
                ", feedbackDate=" + feedbackDate +
                '}';
    }
}
