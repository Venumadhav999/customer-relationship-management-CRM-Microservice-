package com.example.support_and_analytics_service.Entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;

@Entity
public class SupportTicket {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerId;
    private String issueDescription;
    private String status;
    private LocalDateTime createdDate;
    private LocalDateTime resolvedDate;

    // Default constructor
    public SupportTicket() {}

    // Parameterized constructor
    public SupportTicket(String customerId, String issueDescription, String status, LocalDateTime createdDate, LocalDateTime resolvedDate) {
        this.customerId = customerId;
        this.issueDescription = issueDescription;
        this.status = status;
        this.createdDate = createdDate;
        this.resolvedDate = resolvedDate;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getIssueDescription() {
        return issueDescription;
    }

    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(LocalDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public LocalDateTime getResolvedDate() {
        return resolvedDate;
    }

    public void setResolvedDate(LocalDateTime resolvedDate) {
        this.resolvedDate = resolvedDate;
    }

    @Override
    public String toString() {
        return "SupportTicket{" +
                "id=" + id +
                ", customerId='" + customerId + '\'' +
                ", issueDescription='" + issueDescription + '\'' +
                ", status='" + status + '\'' +
                ", createdDate=" + createdDate +
                ", resolvedDate=" + resolvedDate +
                '}';
    }
}
