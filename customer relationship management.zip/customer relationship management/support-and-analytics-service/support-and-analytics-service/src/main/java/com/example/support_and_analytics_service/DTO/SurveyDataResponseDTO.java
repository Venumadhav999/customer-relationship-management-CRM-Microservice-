package com.example.support_and_analytics_service.DTO;

import com.example.support_and_analytics_service.Entity.Customer;
import com.example.support_and_analytics_service.Entity.Survey;
import com.example.support_and_analytics_service.Entity.SurveyResponse;

public class SurveyDataResponseDTO {
    private SurveyResponse surveyResponse;
    private Customer customer;
    private Survey survey;

    public SurveyDataResponseDTO() {
    }

    public SurveyDataResponseDTO(SurveyResponse surveyResponse, Customer customer, Survey survey) {
        this.surveyResponse = surveyResponse;
        this.customer = customer;
        this.survey = survey;
    }

    public SurveyResponse getSurveyResponse() {
        return surveyResponse;
    }

    public void setSurveyResponse(SurveyResponse surveyResponse) {
        this.surveyResponse = surveyResponse;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Survey getSurvey() {
        return survey;
    }

    public void setSurvey(Survey survey) {
        this.survey = survey;
    }
}
