package com.example.support_and_analytics_service.Controller;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.support_and_analytics_service.DTO.FeedbackResponse;
import com.example.support_and_analytics_service.Entity.Feedback;
import com.example.support_and_analytics_service.Service.FeedbackService;
import com.example.support_and_analytics_service.Client.CustomerClient;
import com.example.support_and_analytics_service.Entity.Customer;

@RestController
@RequestMapping("/api/feedbacks")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;

    @Autowired
    private CustomerClient customerClient;

    public FeedbackController(FeedbackService feedbackService, CustomerClient customerClient) {
        this.feedbackService = feedbackService;
        this.customerClient = customerClient;
    }

    @GetMapping
    public List<FeedbackResponse> getAllFeedbacks() {
        List<Feedback> feedbacks = feedbackService.getAllFeedbacks();
        return feedbacks.stream()
                .map(feedback -> {
                    Customer customer = customerClient.getCustomerById(Long.parseLong(feedback.getCustomerId()));
                    return new FeedbackResponse(feedback, customer);
                })
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    public ResponseEntity<FeedbackResponse> getFeedbackById(@PathVariable Long id) {
        Optional<Feedback> feedback = feedbackService.getFeedbackById(id);
        if (feedback.isPresent()) {
            Customer customer = customerClient.getCustomerById(Long.parseLong(feedback.get().getCustomerId()));
            return new ResponseEntity<>(new FeedbackResponse(feedback.get(), customer), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<FeedbackResponse> createFeedback(@RequestBody Feedback feedback) {
        try {
            Customer customer = customerClient.getCustomerById(Long.parseLong(feedback.getCustomerId()));
            if (customer != null) {
                feedback.setCustomerId(customer.getId().toString());
                Feedback createdFeedback = feedbackService.createFeedback(feedback);
                return new ResponseEntity<>(new FeedbackResponse(createdFeedback, customer), HttpStatus.CREATED);
            } else {
                return new ResponseEntity<>(HttpStatus.NOT_FOUND);
            }
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<FeedbackResponse> updateFeedback(@PathVariable Long id, @RequestBody Feedback feedbackDetails) {
        Feedback updatedFeedback = feedbackService.updateFeedback(id, feedbackDetails);
        if (updatedFeedback != null) {
            Customer customer = customerClient.getCustomerById(Long.parseLong(updatedFeedback.getCustomerId()));
            return new ResponseEntity<>(new FeedbackResponse(updatedFeedback, customer), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFeedback(@PathVariable Long id) {
        feedbackService.deleteFeedback(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
