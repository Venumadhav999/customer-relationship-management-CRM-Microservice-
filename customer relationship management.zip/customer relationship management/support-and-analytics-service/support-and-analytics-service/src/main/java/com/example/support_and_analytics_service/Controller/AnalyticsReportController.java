package com.example.support_and_analytics_service.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.support_and_analytics_service.Entity.AnalyticsReport;
import com.example.support_and_analytics_service.Service.AnalyticsReportService;

@RestController
@RequestMapping("/api/analyticsReports")
public class AnalyticsReportController {

    @Autowired
    private AnalyticsReportService analyticsReportService;

    @GetMapping
    public List<AnalyticsReport> getAllAnalyticsReports() {
        return analyticsReportService.getAllAnalyticsReports();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AnalyticsReport> getAnalyticsReportByID(@PathVariable Long id) {
        Optional<AnalyticsReport> analyticsReport = analyticsReportService.getAnalyticsReportByID(id);
        if (analyticsReport.isPresent()) {
            return new ResponseEntity<>(analyticsReport.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<AnalyticsReport> createAnalyticsReport(@RequestBody AnalyticsReport analyticsReport) {
        AnalyticsReport createdAnalyticsReport = analyticsReportService.CreateAnalyticsReport(analyticsReport);
        return new ResponseEntity<>(createdAnalyticsReport, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AnalyticsReport> updateAnalyticsReport(@PathVariable Long id, @RequestBody AnalyticsReport analyticsReportDetails) {
        AnalyticsReport updatedAnalyticsReport = analyticsReportService.updateAnalyticsReport(id, analyticsReportDetails);
        if (updatedAnalyticsReport != null) {
            return new ResponseEntity<>(updatedAnalyticsReport, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAnalyticsReport(@PathVariable Long id) {
        analyticsReportService.deleteAnalyticsReport(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
