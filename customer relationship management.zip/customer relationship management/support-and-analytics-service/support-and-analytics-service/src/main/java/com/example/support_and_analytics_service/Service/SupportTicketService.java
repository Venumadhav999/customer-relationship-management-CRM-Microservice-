package com.example.support_and_analytics_service.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.support_and_analytics_service.Entity.SupportTicket;
import com.example.support_and_analytics_service.Repository.SupportTicketRepository;

@Service
public class SupportTicketService {

    @Autowired
    private SupportTicketRepository supportTicketRepository;

    public List<SupportTicket> getSupportTicketAll(){
        return supportTicketRepository.findAll();
    }

    public Optional<SupportTicket> getSupportTicketById(Long id){
        return supportTicketRepository.findById(id);
    }

    public SupportTicket createSupportTicket(SupportTicket supportTicket){
        return supportTicketRepository.save(supportTicket);
    }

    public void deleteSupportTicket(Long id){
        supportTicketRepository.deleteById(id);
    }

    public SupportTicket updateSupportTicket(Long id, SupportTicket supportTicketDetails){
        Optional<SupportTicket> supportTicketOptional = supportTicketRepository.findById(id);

        if(supportTicketOptional.isPresent()){
            SupportTicket supportTicket = supportTicketOptional.get();
            supportTicket.setCustomerId(supportTicketDetails.getCustomerId());
            supportTicket.setIssueDescription(supportTicketDetails.getIssueDescription());
            supportTicket.setStatus(supportTicketDetails.getStatus());
            supportTicket.setCreatedDate(supportTicketDetails.getCreatedDate());
            supportTicket.setResolvedDate(supportTicketDetails.getResolvedDate());

            return supportTicketRepository.save(supportTicket);
        } else {
            return null;
        }
    }
}
