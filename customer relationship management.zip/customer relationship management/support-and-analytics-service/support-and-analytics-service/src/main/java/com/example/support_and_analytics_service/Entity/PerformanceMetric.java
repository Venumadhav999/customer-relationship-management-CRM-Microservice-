package com.example.support_and_analytics_service.Entity;

import jakarta.persistence.*;

@Entity
public class PerformanceMetric {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String metricName;
    private double value;
    private String unit;

    // Default constructor
    public PerformanceMetric() {}

    // Parameterized constructor
    public PerformanceMetric(String metricName, double value, String unit) {
        this.metricName = metricName;
        this.value = value;
        this.unit = unit;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMetricName() {
        return metricName;
    }

    public void setMetricName(String metricName) {
        this.metricName = metricName;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "PerformanceMetric{" +
                "id=" + id +
                ", metricName='" + metricName + '\'' +
                ", value=" + value +
                ", unit='" + unit + '\'' +
                '}';
    }
}

