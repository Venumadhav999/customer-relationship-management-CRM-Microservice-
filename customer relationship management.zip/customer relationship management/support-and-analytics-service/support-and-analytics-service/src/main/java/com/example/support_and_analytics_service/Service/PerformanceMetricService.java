package com.example.support_and_analytics_service.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.support_and_analytics_service.Entity.PerformanceMetric;
import com.example.support_and_analytics_service.Repository.PerformanceMetricRepository;

@Service
public class PerformanceMetricService {

    @Autowired
    private PerformanceMetricRepository performanceMetricRepository;

    public List<PerformanceMetric> getPerformanceMetricAll(){
        return performanceMetricRepository.findAll();
    }

    public Optional<PerformanceMetric> getPerformanceMetricById(Long id){
        return performanceMetricRepository.findById(id);
    }

    public PerformanceMetric createPerformanceMetric(PerformanceMetric performanceMetric){
        return performanceMetricRepository.save(performanceMetric);
    }

    public void deletePerformanceMetric(Long id){
        performanceMetricRepository.deleteById(id);
    }

    public PerformanceMetric updatePerformanceMetric (Long id, PerformanceMetric performanceMetricDeatiles){
        Optional<PerformanceMetric> performanceMetricOptional = performanceMetricRepository.findById(id);

        if(performanceMetricOptional.isPresent()){
            PerformanceMetric performanceMetric = performanceMetricOptional.get();
            performanceMetric.setMetricName(performanceMetricDeatiles.getMetricName());
            performanceMetric.setUnit(performanceMetricDeatiles.getUnit());
            performanceMetric.setValue(performanceMetric.getValue());

            return performanceMetricRepository.save(performanceMetric);
        }
        else{
            return null;
        }
    }
    
}
