package com.example.support_and_analytics_service.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.support_and_analytics_service.Entity.PerformanceMetric;
import com.example.support_and_analytics_service.Service.PerformanceMetricService;

@RestController
@RequestMapping("/api/performanceMetrics")
public class PerformanceMetricController {

    @Autowired
    private PerformanceMetricService performanceMetricService;

    @GetMapping
    public List<PerformanceMetric> getAllPerformanceMetrics() {
        return performanceMetricService.getPerformanceMetricAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<PerformanceMetric> getPerformanceMetricById(@PathVariable Long id) {
        Optional<PerformanceMetric> performanceMetric = performanceMetricService.getPerformanceMetricById(id);
        if (performanceMetric.isPresent()) {
            return new ResponseEntity<>(performanceMetric.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping
    public ResponseEntity<PerformanceMetric> createPerformanceMetric(@RequestBody PerformanceMetric performanceMetric) {
        PerformanceMetric createdPerformanceMetric = performanceMetricService.createPerformanceMetric(performanceMetric);
        return new ResponseEntity<>(createdPerformanceMetric, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<PerformanceMetric> updatePerformanceMetric(@PathVariable Long id, @RequestBody PerformanceMetric performanceMetricDetails) {
        PerformanceMetric updatedPerformanceMetric = performanceMetricService.updatePerformanceMetric(id, performanceMetricDetails);
        if (updatedPerformanceMetric != null) {
            return new ResponseEntity<>(updatedPerformanceMetric, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePerformanceMetric(@PathVariable Long id) {
        performanceMetricService.deletePerformanceMetric(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
