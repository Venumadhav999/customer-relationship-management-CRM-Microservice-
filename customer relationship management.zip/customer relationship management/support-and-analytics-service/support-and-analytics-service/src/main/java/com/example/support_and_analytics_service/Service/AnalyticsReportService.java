package com.example.support_and_analytics_service.Service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.support_and_analytics_service.Entity.AnalyticsReport;
import com.example.support_and_analytics_service.Repository.AnalyticsReportRepository;


@Service
public class AnalyticsReportService {

    @Autowired
    private AnalyticsReportRepository analyticsReportRepository;

    public List<AnalyticsReport> getAllAnalyticsReports(){
        return analyticsReportRepository.findAll();
    }

    public Optional<AnalyticsReport> getAnalyticsReportByID(Long id){
        return analyticsReportRepository.findById(id);
    }

    public AnalyticsReport CreateAnalyticsReport(AnalyticsReport analyticsReport){
        return analyticsReportRepository.save(analyticsReport);
    }


    public void deleteAnalyticsReport (Long id){
        analyticsReportRepository.deleteById(id);
    }
    public AnalyticsReport updateAnalyticsReport (Long id, AnalyticsReport analyticsReportDeatiles){
        Optional<AnalyticsReport> analyticsReportOptional = analyticsReportRepository.findById(id);

        if(analyticsReportOptional.isPresent()){
            AnalyticsReport analyticsReport = analyticsReportOptional.get();
            analyticsReport.setReportName(analyticsReportDeatiles.getReportName());
            analyticsReport.setReportData(analyticsReportDeatiles.getReportData());
            analyticsReport.setGeneratedDate(analyticsReport.getGeneratedDate());

            return analyticsReportRepository.save(analyticsReport);
        }
        else{
            return null;
        }
    }
}
