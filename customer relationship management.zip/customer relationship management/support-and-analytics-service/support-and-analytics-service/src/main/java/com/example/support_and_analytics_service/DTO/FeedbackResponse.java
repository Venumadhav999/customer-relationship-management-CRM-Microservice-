package com.example.support_and_analytics_service.DTO;

import com.example.support_and_analytics_service.Entity.Customer;
import com.example.support_and_analytics_service.Entity.Feedback;

public class FeedbackResponse {
    private Feedback feedback;
    private Customer customer;

    

    public FeedbackResponse() {
    }

    public FeedbackResponse(Feedback feedback, Customer customer) {
        this.feedback = feedback;
        this.customer = customer;
    }

    // Getters and setters
    public Feedback getFeedback() {
        return feedback;
    }

    public void setFeedback(Feedback feedback) {
        this.feedback = feedback;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }
}
