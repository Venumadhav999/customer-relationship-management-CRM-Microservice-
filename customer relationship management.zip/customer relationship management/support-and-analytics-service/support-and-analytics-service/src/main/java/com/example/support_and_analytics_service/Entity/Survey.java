package com.example.support_and_analytics_service.Entity;

import java.util.Date;

public class Survey {
    private Long surveyId;
    private String name;
    private String description;
    private Date creationDate;

    // Default constructor
    public Survey() {}

    // Parameterized constructor
    public Survey(Long surveyId, String name, String description, Date creationDate) {
        this.surveyId = surveyId;
        this.name = name;
        this.description = description;
        this.creationDate = creationDate;
    }

    // Getters and setters
    public Long getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(Long surveyId) {
        this.surveyId = surveyId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(Date creationDate) {
        this.creationDate = creationDate;
    }

    @Override
    public String toString() {
        return "Survey{" +
                "surveyId=" + surveyId +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", creationDate=" + creationDate +
                '}';
    }
}