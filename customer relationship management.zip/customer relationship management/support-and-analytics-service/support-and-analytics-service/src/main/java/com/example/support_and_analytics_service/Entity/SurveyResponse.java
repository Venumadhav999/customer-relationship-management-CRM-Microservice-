package com.example.support_and_analytics_service.Entity;

import jakarta.persistence.*;

@Entity
public class SurveyResponse {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String surveyId;
    private String customerId;
    private String response;

    // Default constructor
    public SurveyResponse() {}

    // Parameterized constructor
    public SurveyResponse(String surveyId, String customerId, String response) {
        this.surveyId = surveyId;
        this.customerId = customerId;
        this.response = response;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(String surveyId) {
        this.surveyId = surveyId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @Override
    public String toString() {
        return "SurveyResponse{" +
                "id=" + id +
                ", surveyId='" + surveyId + '\'' +
                ", customerId='" + customerId + '\'' +
                ", response='" + response + '\'' +
                '}';
    }
}

