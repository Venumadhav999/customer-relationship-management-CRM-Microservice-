package com.example.support_and_analytics_service.Entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;

@Entity
public class AnalyticsReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String reportName;
    private String reportData;
    private LocalDateTime generatedDate;

    // Default constructor
    public AnalyticsReport() {}

    // Parameterized constructor
    public AnalyticsReport(String reportName, String reportData, LocalDateTime generatedDate) {
        this.reportName = reportName;
        this.reportData = reportData;
        this.generatedDate = generatedDate;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getReportName() {
        return reportName;
    }

    public void setReportName(String reportName) {
        this.reportName = reportName;
    }

    public String getReportData() {
        return reportData;
    }

    public void setReportData(String reportData) {
        this.reportData = reportData;
    }

    public LocalDateTime getGeneratedDate() {
        return generatedDate;
    }

    public void setGeneratedDate(LocalDateTime generatedDate) {
        this.generatedDate = generatedDate;
    }

    @Override
    public String toString() {
        return "AnalyticsReport{" +
                "id=" + id +
                ", reportName='" + reportName + '\'' +
                ", reportData='" + reportData + '\'' +
                ", generatedDate=" + generatedDate +
                '}';
    }
}
